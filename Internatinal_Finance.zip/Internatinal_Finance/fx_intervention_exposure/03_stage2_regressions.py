"""Estimate cross-sectional and pooled crisis-period intervention regressions.

Implements Sikarwar (2020) Eq. 4-6 and the crisis interaction extension
with period-weighted annual World Bank macro data.
"""

import importlib.util
import logging
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.stats import chi2

from config import (
    BASE_DIR,
    CLEAN_DIR,
    COUNTRIES,
    COVID_WINDOWS,
    GFC_WINDOWS,
    OUTPUT_DIR,
    REPLICATION_END,
    REPLICATION_START,
)

LOG_PATH = OUTPUT_DIR / "stage2.log"
INDUSTRIES = [
    "Energy", "Materials", "Consumer Staples", "Consumer Discretionary",
    "Health Care", "Information Technology", "Communication Services",
    "Utilities", "Real Estate",
]
CONTROLS = ["SIZE", "OPENNESS", "BM_GDP", "LNGDPPC"]


def setup_logging():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        handlers=[logging.FileHandler(LOG_PATH, encoding="utf-8"), logging.StreamHandler()],
        force=True,
    )


def _month_end(series):
    return pd.to_datetime(series).dt.to_period("M").dt.to_timestamp("M")


def _calendar_for_country():
    return pd.read_csv(CLEAN_DIR / "crisis_calendar.csv")


def _overlap_counts(country, period):
    calendar = _calendar_for_country()
    country_calendar = calendar.loc[calendar["country"] == country].copy()
    if period == "OFF":
        selected = country_calendar.loc[country_calendar["period"] == "OFF"].copy()
    elif period == "ON":
        selected = country_calendar.loc[country_calendar["period"] == "ON"].copy()
    elif period == "GFC":
        selected = country_calendar.loc[country_calendar["gfc"] == 1].copy()
    elif period == "COVID":
        selected = country_calendar.loc[country_calendar["covid"] == 1].copy()
    else:
        raise ValueError(f"Unknown period: {period}")
    selected["year"] = selected["month"].str[:4].astype(int)
    return selected.groupby("year").size().to_dict()


def _weighted_average(frame, country, period, value_col):
    weights = _overlap_counts(country, period)
    if not weights:
        return np.nan
    local = frame.loc[frame["iso3"] == COUNTRIES[country]["iso3"]].copy()
    local = local.loc[local["year"].isin(weights)]
    if value_col not in local:
        return np.nan
    local["weight"] = local["year"].map(weights)
    local = local.dropna(subset=[value_col])
    if local.empty or local["weight"].sum() == 0:
        return np.nan
    return float(np.average(local[value_col], weights=local["weight"]))


def build_period_data(intervention_file="intervention_annual.csv"):
    """Aggregate annual intervention and controls using actual month overlap."""
    intervention = pd.read_csv(CLEAN_DIR / intervention_file)
    intervention = intervention.rename(
        columns={
            "intervention": "INT",
            "intervention_reserves_gdp": "INT_RES_GDP",
        }
    )
    intervention["country"] = intervention["iso3"].map(
        {v["iso3"]: country for country, v in COUNTRIES.items()}
    )
    controls = pd.read_csv(CLEAN_DIR / "country_controls_annual.csv")
    control_pivot = controls.pivot_table(
        index=["iso3", "year"], columns="variable", values="value", aggfunc="mean"
    ).reset_index()
    control_pivot = control_pivot.rename(
        columns={
            "openness": "OPENNESS",
            "broad_money_gdp": "BM_GDP",
            "gdp_per_capita_usd": "GDPPC",
        }
    )
    rows = []
    for country in COUNTRIES:
        for period in ("OFF", "ON", "GFC", "COVID"):
            record = {
                "country": country,
                "period": period,
                "INT": _weighted_average(intervention, country, period, "INT"),
                "INT_RES_GDP": _weighted_average(intervention, country, period, "INT_RES_GDP"),
            }
            for variable in ("OPENNESS", "BM_GDP", "GDPPC"):
                source_column = variable if variable != "GDPPC" else "GDPPC"
                record[variable] = _weighted_average(control_pivot, country, period, source_column)
            record["LNGDPPC"] = (
                np.log(record["GDPPC"]) if pd.notna(record["GDPPC"]) and record["GDPPC"] > 0 else np.nan
            )
            rows.append(record)
    output = pd.DataFrame(rows)
    output.to_csv(CLEAN_DIR / "country_period_data.csv", index=False)
    return output


def _replication_country_means():
    intervention = pd.read_csv(CLEAN_DIR / "intervention_annual.csv").rename(
        columns={"intervention": "INT"}
    )
    controls = pd.read_csv(CLEAN_DIR / "country_controls_annual.csv").pivot_table(
        index=["iso3", "year"], columns="variable", values="value", aggfunc="mean"
    ).reset_index().rename(
        columns={
            "openness": "OPENNESS",
            "broad_money_gdp": "BM_GDP",
            "gdp_per_capita_usd": "GDPPC",
        }
    )
    start, end = pd.Period(REPLICATION_START, "M"), pd.Period(REPLICATION_END, "M")
    years = list(range(start.year, end.year + 1))
    weights = {
        year: sum(1 for month in pd.period_range(start, end, freq="M") if month.year == year)
        for year in years
    }
    rows = []
    for country, metadata in COUNTRIES.items():
        record = {"country": country}
        for data, source_col, target in (
            (intervention, "INT", "INT"),
            (controls, "OPENNESS", "OPENNESS"),
            (controls, "BM_GDP", "BM_GDP"),
            (controls, "GDPPC", "GDPPC"),
        ):
            local = data.loc[
                (data["iso3"] == metadata["iso3"]) & data["year"].isin(weights)
            ].copy()
            local = local.dropna(subset=[source_col])
            record[target] = (
                float(np.average(local[source_col], weights=local["year"].map(weights)))
                if not local.empty else np.nan
            )
        record["LNGDPPC"] = (
            np.log(record["GDPPC"]) if pd.notna(record["GDPPC"]) and record["GDPPC"] > 0 else np.nan
        )
        rows.append(record)
    return pd.DataFrame(rows)


def _sector_dummies(frame):
    frame = frame.copy()
    frame["sector"] = frame["sector"].where(frame["sector"].isin(INDUSTRIES + ["Industrials"]), "Other")
    for industry in INDUSTRIES:
        frame[f"IND_{industry.replace(' ', '_')}"] = (frame["sector"] == industry).astype(int)
    return frame


def _prepare_cross_section(replication):
    info = pd.read_csv(CLEAN_DIR / "firm_info.csv")
    info["market_cap"] = pd.to_numeric(info["market_cap"], errors="coerce")
    info["SIZE"] = np.where(info["market_cap"] > 0, np.log(info["market_cap"]), np.nan)
    frame = replication.merge(
        info[["ticker", "SIZE"]].rename(columns={"ticker": "firm"}),
        on="firm",
        how="left",
    )
    frame = frame.merge(
        pd.read_csv(CLEAN_DIR / "firm_prices_monthly.csv")[["ticker", "country", "sector"]]
        .drop_duplicates("ticker")
        .rename(columns={"ticker": "firm", "sector": "sector_listed"}),
        on=["firm", "country"],
        how="left",
    )
    frame["sector"] = frame["sector"].fillna(frame["sector_listed"])
    return _sector_dummies(frame)


def _add_country_period_variables(frame, period_data, period_col):
    frame = frame.merge(
        period_data.rename(columns={"period": period_col}),
        on=["country", period_col],
        how="left",
        suffixes=("", "_country"),
    )
    frame["D_SALE"] = (frame["INT"] < 0).astype(float)
    return frame


def _numeric_design(frame, columns, label):
    """Remove missing, constant, and linearly dependent terms and log each removal."""
    y = pd.to_numeric(frame["dependent"], errors="coerce")
    X = frame[columns].apply(pd.to_numeric, errors="coerce")
    valid = y.notna() & X.notna().all(axis=1)
    y, X, frame = y.loc[valid], X.loc[valid], frame.loc[valid].copy()
    kept = []
    matrix = np.ones((len(X), 1))
    for column in columns:
        values = X[column].to_numpy(dtype=float)
        if len(np.unique(values)) <= 1:
            logging.info("%s: dropped constant/empty regressor %s", label, column)
            continue
        candidate = np.column_stack([matrix, values])
        if np.linalg.matrix_rank(candidate) < candidate.shape[1]:
            logging.info("%s: dropped perfectly collinear regressor %s", label, column)
            continue
        kept.append(column)
        matrix = candidate
    design = sm.add_constant(X[kept], has_constant="add")
    return y, design, frame, kept


def _fit_models(frame, dependent, columns, cluster_col, label):
    frame = frame.copy()
    frame["dependent"] = pd.to_numeric(frame[dependent], errors="coerce")
    y, X, used_frame, kept = _numeric_design(frame, columns, label)
    if len(y) <= len(kept) + 2:
        logging.warning("%s: too few observations (%d)", label, len(y))
        return None, None, used_frame, kept
    base = sm.OLS(y, X).fit()
    try:
        hc1 = base.get_robustcov_results(cov_type="HC1")
    except Exception as exc:
        logging.warning("%s: HC1 covariance unavailable: %s", label, exc)
        hc1 = base
    clustered = {}
    for group_col in dict.fromkeys((cluster_col, "country", "firm")):
        if group_col in used_frame and used_frame[group_col].nunique() > 1:
            try:
                clustered[group_col] = base.get_robustcov_results(
                    cov_type="cluster",
                    groups=used_frame[group_col].astype(str).to_numpy(),
                    use_correction=True,
                )
            except Exception as exc:
                logging.warning("%s: %s-cluster covariance unavailable: %s", label, group_col, exc)
    cluster = clustered.get(cluster_col)
    country_cluster = clustered.get("country")
    firm_cluster = clustered.get("firm")
    if cluster is None and cluster_col in used_frame and used_frame[cluster_col].nunique() > 1:
        logging.warning("%s: cluster covariance unavailable for %s", label, cluster_col)
    result_rows = []
    name_order = list(X.columns)
    for i, term in enumerate(name_order):
        result_rows.append(
            {
                "model": label,
                "term": term,
                "coef": float(hc1.params[i]),
                "se_hc1": float(hc1.bse[i]),
                "p_hc1": float(hc1.pvalues[i]),
                "se_cluster": float(cluster.bse[i]) if cluster is not None else np.nan,
                "p_cluster": float(cluster.pvalues[i]) if cluster is not None else np.nan,
                "se_country_cluster": float(country_cluster.bse[i]) if country_cluster is not None else np.nan,
                "p_country_cluster": float(country_cluster.pvalues[i]) if country_cluster is not None else np.nan,
                "se_firm_cluster": float(firm_cluster.bse[i]) if firm_cluster is not None else np.nan,
                "p_firm_cluster": float(firm_cluster.pvalues[i]) if firm_cluster is not None else np.nan,
                "n_obs": int(base.nobs),
                "r2": float(base.rsquared),
                "adj_r2": float(base.rsquared_adj),
                "cluster_groups": int(used_frame[cluster_col].nunique())
                if cluster_col in used_frame else 0,
                "cluster_note": (
                    "Country-clustered SE; few clusters, interpret cautiously"
                    if cluster_col == "country" else "Firm-clustered SE"
                ),
            }
        )
    return base, pd.DataFrame(result_rows), used_frame, kept


def _contrast(result, first, second, sign=1, covariance=None):
    """Return a linear-combination estimate, standard error and two-sided p-value."""
    if result is None:
        return np.nan, np.nan, np.nan
    names = list(result.model.exog_names)
    if first not in names or second not in names:
        return np.nan, np.nan, np.nan
    contrast = np.zeros(len(names))
    contrast[names.index(first)] = 1
    contrast[names.index(second)] = sign
    params = np.asarray(result.params)
    covariance = np.asarray(covariance if covariance is not None else result.cov_params())
    estimate = float(contrast @ params)
    variance = float(contrast @ covariance @ contrast)
    if variance <= 0 or not np.isfinite(variance):
        return estimate, np.nan, np.nan
    se = float(np.sqrt(variance))
    pvalue = float(2 * __import__("scipy").stats.norm.sf(abs(estimate / se)))
    return estimate, se, pvalue


def run_replication():
    replication = pd.read_csv(OUTPUT_DIR / "stage1_replication.csv")
    frame = _prepare_cross_section(replication)
    # Eq.(4-6) country variables are month-weighted over 2001-04 to 2017-03.
    frame = frame.merge(_replication_country_means(), on="country", how="left")
    frame["D_SALE"] = (frame["INT"] < 0).astype(float)
    returns = pd.read_csv(CLEAN_DIR / "return_panel.csv", parse_dates=["date"])
    rep_returns = returns.loc[
        returns["date"].dt.to_period("M").astype(str).between(REPLICATION_START, REPLICATION_END)
    ].drop_duplicates(["country", "date"])
    depreciation = rep_returns.groupby("country")["ret_neer"].mean().lt(0).astype(int).to_dict()
    frame["D_DEP"] = frame["country"].map(depreciation).astype(float)
    frame["D_SALE_INT"] = frame["D_SALE"] * frame["INT"]
    frame["D_DEP_INT"] = frame["D_DEP"] * frame["INT"]
    frame["D_DEP_DSALE_INT"] = frame["D_DEP"] * frame["D_SALE"] * frame["INT"]
    sector_columns = [f"IND_{value.replace(' ', '_')}" for value in INDUSTRIES]
    base_columns = ["INT"] + CONTROLS + sector_columns
    model_results = []
    tables = {4: [], 5: [], 6: []}
    samples = {
        "all_abs_beta": (frame.copy(), "beta_s_abs"),
        "significant_abs_beta": (frame.loc[frame["sig10"]].copy(), "beta_s_abs"),
        "positive_signed_beta": (frame.loc[frame["beta_s"] > 0].copy(), "beta_s"),
        "negative_signed_beta": (frame.loc[frame["beta_s"] < 0].copy(), "beta_s"),
    }
    frame["beta_s_abs"] = frame["beta_s"].abs()
    for sample_name, (sample, dependent) in samples.items():
        sample = sample.copy()
        if dependent == "beta_s_abs" and "beta_s_abs" not in sample:
            sample["beta_s_abs"] = sample["beta_s"].abs()
        # Eq.(4): |b_s,i| = g0 + g_INT*INT + g_SIZE*SIZE + country controls + industries + u.
        # Eq.(5): Eq.(4) + g_D*(D_SALE*INT).
        # Eq.(6): Eq.(5) + D_DEP + D_DEP*INT + D_DEP*D_SALE*INT.
        for eq, columns in (
            (4, base_columns),
            (5, base_columns + ["D_SALE_INT"]),
            (6, base_columns + ["D_SALE_INT", "D_DEP", "D_DEP_INT", "D_DEP_DSALE_INT"]),
        ):
            label = f"Eq{eq}_{sample_name}"
            fit, result, used, _ = _fit_models(sample, dependent, columns, "country", label)
            if result is None:
                result = pd.DataFrame(
                    [{
                        "model": label,
                        "term": "MODEL_STATUS",
                        "coef": np.nan,
                        "se_hc1": np.nan,
                        "p_hc1": np.nan,
                        "se_cluster": np.nan,
                        "p_cluster": np.nan,
                        "se_country_cluster": np.nan,
                        "p_country_cluster": np.nan,
                        "se_firm_cluster": np.nan,
                        "p_firm_cluster": np.nan,
                        "n_obs": len(used),
                        "r2": np.nan,
                        "adj_r2": np.nan,
                        "cluster_groups": used["country"].nunique() if "country" in used else 0,
                        "cluster_note": "Not estimable: too few observations for this sample",
                    }]
                )
            result["sample"] = sample_name
            result["equation"] = eq
            model_results.append(result)
            tables[eq].append(result)
    all_results = pd.concat(model_results, ignore_index=True) if model_results else pd.DataFrame()
    all_results.to_csv(OUTPUT_DIR / "stage2_replication.csv", index=False)
    for equation, rows in tables.items():
        table = pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()
        table.to_csv(OUTPUT_DIR / f"Table{equation - 1}_eq{equation}.csv", index=False)
    logging.info("Stage 2 replication complete: %d firms across %d countries",
                 frame["firm"].nunique(), frame["country"].nunique())
    return frame, all_results


def _period_exposure_panel(extension_file="stage1_on_off.csv", intervention_file="intervention_annual.csv"):
    exposure = pd.read_csv(OUTPUT_DIR / extension_file)
    exposure = exposure.loc[exposure["model"] == "crisis_on_off"].copy()
    exposure = exposure.loc[exposure["period"].isin(["OFF", "ON"])]
    exposure = exposure.drop_duplicates(["firm", "country", "period"])
    exposure["dependent"] = exposure["abs_beta"]
    info = pd.read_csv(CLEAN_DIR / "firm_info.csv")
    info["market_cap"] = pd.to_numeric(info["market_cap"], errors="coerce")
    info["SIZE"] = np.where(info["market_cap"] > 0, np.log(info["market_cap"]), np.nan)
    exposure = exposure.merge(
        info[["ticker", "SIZE"]].rename(columns={"ticker": "firm"}), on="firm", how="left"
    )
    exposure = _sector_dummies(exposure)
    period_data = build_period_data(intervention_file)
    exposure = _add_country_period_variables(exposure, period_data, "period")
    exposure["CRISIS"] = (exposure["period"] == "ON").astype(float)
    exposure["INT_CRISIS"] = exposure["INT"] * exposure["CRISIS"]
    exposure["D_SALE_INT"] = exposure["D_SALE"] * exposure["INT"]
    exposure["D_SALE_INT_CRISIS"] = exposure["D_SALE_INT"] * exposure["CRISIS"]

    return exposure, period_data


def _country_depreciation_by_period():
    returns = pd.read_csv(CLEAN_DIR / "return_panel.csv", parse_dates=["date"])
    returns["month"] = returns["date"].dt.to_period("M").astype(str)
    calendar = _calendar_for_country()
    calendar = calendar.merge(returns[["country", "month", "ret_neer"]].drop_duplicates(),
                              on=["country", "month"], how="left")
    values = []
    for country, group in calendar.groupby("country"):
        for period_name, mask in (
            ("OFF", group["period"] == "OFF"),
            ("ON", group["period"] == "ON"),
            ("GFC", group["gfc"] == 1),
            ("COVID", group["covid"] == 1),
        ):
            avg = group.loc[mask, "ret_neer"].mean()
            values.append({"country": country, "period": period_name,
                           "D_DEP": float(avg < 0) if pd.notna(avg) else np.nan})
    return pd.DataFrame(values)


def _add_depreciation_terms(frame):
    dep = _country_depreciation_by_period()
    frame = frame.merge(dep, on=["country", "period"], how="left", suffixes=("", "_dep"))
    frame["D_DEP_INT"] = frame["D_DEP"] * frame["INT"]
    frame["D_DEP_DSALE_INT"] = frame["D_DEP"] * frame["D_SALE"] * frame["INT"]
    frame["D_DEP_CRISIS"] = frame["D_DEP"] * frame["CRISIS"]
    frame["D_DEP_INT_CRISIS"] = frame["D_DEP_INT"] * frame["CRISIS"]
    frame["D_DEP_DSALE_INT_CRISIS"] = frame["D_DEP_DSALE_INT"] * frame["CRISIS"]
    return frame


def _fit_extension_models(exposure, significant_only=False, suffix=""):
    frame = exposure.copy()
    if significant_only:
        stage1 = pd.read_csv(OUTPUT_DIR / "stage1_replication.csv")[["firm", "sig10"]]
        significant_firms = set(stage1.loc[stage1["sig10"], "firm"])
        frame = frame.loc[frame["firm"].isin(significant_firms)]
    industry_terms = [f"IND_{value.replace(' ', '_')}" for value in INDUSTRIES]
    # Main extension: |b_i,p| = a + g1*INT + g2*CRISIS + g3*(INT*CRISIS) + controls + e.
    control_terms = ["INT", "CRISIS", "INT_CRISIS"] + CONTROLS + industry_terms
    asym_terms = control_terms + ["D_SALE_INT", "D_SALE_INT_CRISIS"]
    depreciation = _add_depreciation_terms(frame)
    dep_terms = asym_terms + [
        "D_DEP", "D_DEP_INT", "D_DEP_DSALE_INT", "D_DEP_CRISIS",
        "D_DEP_INT_CRISIS", "D_DEP_DSALE_INT_CRISIS",
    ]
    summaries, coefficients = [], []
    selected_fit = None
    for label, terms in (
        ("main", control_terms),
        ("asymmetric", asym_terms),
        ("depreciation", dep_terms),
    ):
        fit, result, used_frame, _ = _fit_models(
            depreciation, "dependent", terms, "firm", f"extension_{label}{suffix}"
        )
        if result is None:
            continue
        result["model_type"] = label
        coefficients.append(result)
        if label == "main":
            selected_fit = fit
            firm_cov = fit.get_robustcov_results(
                cov_type="cluster", groups=used_frame["firm"].astype(str).to_numpy(),
                use_correction=True,
            )
            g1, g1_se, g1_p = _contrast(
                fit, "INT", "INT_CRISIS", sign=0, covariance=firm_cov.cov_params()
            )
            on, on_se, on_p = _contrast(
                fit, "INT", "INT_CRISIS", sign=1, covariance=firm_cov.cov_params()
            )
            interaction = result.loc[result["term"] == "INT_CRISIS"]
            summaries.append(
                {
                    "model": f"main{suffix}", "sample": "significant" if significant_only else "all",
                    "g1": _term_value(result, "INT", "coef"),
                    "g1_p": _term_value(result, "INT", "p_firm_cluster"),
                    "g3": _term_value(result, "INT_CRISIS", "coef"),
                    "g3_p": _term_value(result, "INT_CRISIS", "p_firm_cluster"),
                    "g1_plus_g3": on, "g1_plus_g3_se": on_se, "g1_plus_g3_p": on_p,
                    "g1_se": g1_se,
                    "n_obs": int(result["n_obs"].iloc[0]),
                }
            )
    coefficients_frame = pd.concat(coefficients, ignore_index=True) if coefficients else pd.DataFrame()
    return selected_fit, coefficients_frame, pd.DataFrame(summaries)


def _term_value(frame, term, col):
    found = frame.loc[frame["term"] == term, col]
    return float(found.iloc[0]) if not found.empty else np.nan


def _run_split_model(extension_file="stage1_on_off.csv", significant_only=False, suffix=""):
    rows = pd.read_csv(OUTPUT_DIR / extension_file)
    rows = rows.loc[(rows["model"] == "gfc_covid") & rows["period"].isin(["OFF", "GFC", "COVID"])].copy()
    rows["dependent"] = rows["abs_beta"]
    info = pd.read_csv(CLEAN_DIR / "firm_info.csv")
    info["market_cap"] = pd.to_numeric(info["market_cap"], errors="coerce")
    info["SIZE"] = np.where(info["market_cap"] > 0, np.log(info["market_cap"]), np.nan)
    rows = rows.merge(info[["ticker", "SIZE"]].rename(columns={"ticker": "firm"}), on="firm", how="left")
    rows = _sector_dummies(rows)
    periods = build_period_data()
    rows = _add_country_period_variables(rows, periods, "period")
    if significant_only:
        firms = pd.read_csv(OUTPUT_DIR / "stage1_replication.csv")
        rows = rows.loc[rows["firm"].isin(firms.loc[firms["sig10"], "firm"])]
    rows["GFC"] = (rows["period"] == "GFC").astype(float)
    rows["COVID"] = (rows["period"] == "COVID").astype(float)
    rows["INT_GFC"] = rows["INT"] * rows["GFC"]
    rows["INT_COVID"] = rows["INT"] * rows["COVID"]
    terms = ["INT", "GFC", "COVID", "INT_GFC", "INT_COVID"] + CONTROLS + [
        f"IND_{value.replace(' ', '_')}" for value in INDUSTRIES
    ]
    fit, result, used_frame, _ = _fit_models(rows, "dependent", terms, "firm", f"split{suffix}")
    if fit is not None:
        covariance = fit.get_robustcov_results(
            cov_type="cluster", groups=used_frame["firm"].astype(str).to_numpy(),
            use_correction=True,
        ).cov_params()
        p_equal = _contrast(fit, "INT_GFC", "INT_COVID", sign=-1, covariance=covariance)[2]
    else:
        p_equal = np.nan
    if result is not None:
        result.to_csv(OUTPUT_DIR / f"stage2_split{suffix}.csv", index=False)
    summary = pd.DataFrame(
        [{"model": f"split{suffix}", "g3_gfc": _term_value(result, "INT_GFC", "coef") if result is not None else np.nan,
          "g3_gfc_p": _term_value(result, "INT_GFC", "p_hc1") if result is not None else np.nan,
          "g3_covid": _term_value(result, "INT_COVID", "coef") if result is not None else np.nan,
          "g3_covid_p": _term_value(result, "INT_COVID", "p_hc1") if result is not None else np.nan,
          "gfc_equals_covid_p": p_equal}]
    )
    return summary


def _chow_test(exposure):
    frame = exposure.copy()
    terms = ["INT", "SIZE", "OPENNESS", "BM_GDP", "LNGDPPC"] + [
        f"IND_{value.replace(' ', '_')}" for value in INDUSTRIES
    ]
    base = frame[terms].copy()
    interaction_terms = []
    for term in terms:
        if term == "INT":
            name = "INT_CRISIS"
            base[name] = frame[term] * frame["CRISIS"]
        else:
            name = f"{term}_CRISIS"
            base[name] = frame[term] * frame["CRISIS"]
        interaction_terms.append(name)
    base["dependent"] = frame["dependent"]
    base["firm"] = frame["firm"]
    base["country"] = frame["country"]
    fit, _, _, _ = _fit_models(base, "dependent", list(terms) + interaction_terms, "firm", "chow")
    if fit is None:
        return np.nan
    names = list(fit.model.exog_names)
    selected = [names.index(term) for term in interaction_terms if term in names]
    if not selected:
        return np.nan
    restriction = np.zeros((len(selected), len(names)))
    for row, index in enumerate(selected):
        restriction[row, index] = 1
    try:
        return float(fit.f_test(restriction).pvalue)
    except Exception as exc:
        logging.warning("Chow-style F-test failed: %s", exc)
        return np.nan


def run_robustness(main_summary):
    records = []
    if not main_summary.empty:
        for row in main_summary.itertuples(index=False):
            records.append(
                {"check": "baseline", "g3": row.g3, "g3_p": row.g3_p,
                 "g1_plus_g3": row.g1_plus_g3, "g1_plus_g3_p": row.g1_plus_g3_p}
            )

    exposure, _ = _period_exposure_panel()
    no_korea = exposure.loc[exposure["country"] != "Korea"]
    _, _, no_korea_summary = _fit_extension_models(no_korea, suffix="_exclude_korea")
    records.extend(_summary_records(no_korea_summary, "exclude_Korea"))
    sqrt_frame = exposure.copy()
    sqrt_frame["dependent"] = np.sqrt(sqrt_frame["abs_beta"].clip(lower=0))
    _, _, sqrt_summary = _fit_extension_models(sqrt_frame, suffix="_sqrt_abs_beta")
    records.extend(_summary_records(sqrt_summary, "sqrt_abs_beta"))

    module_path = BASE_DIR / "02_stage1_exposure.py"
    spec = importlib.util.spec_from_file_location("stage1_module", module_path)
    stage1 = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(stage1)
    _, world_exposure, _ = stage1.run_stage1(world_market=True, write_outputs=True)
    world_exposure.to_csv(OUTPUT_DIR / "stage1_on_off_world.csv", index=False)
    world_panel, _ = _period_exposure_panel("stage1_on_off_world.csv")
    _, _, world_summary = _fit_extension_models(world_panel, suffix="_world_market")
    records.extend(_summary_records(world_summary, "world_market"))

    alternative_file = CLEAN_DIR / "intervention_reserves_gdp_annual.csv"
    if alternative_file.exists():
        alt_panel, _ = _period_exposure_panel(intervention_file="intervention_reserves_gdp_annual.csv")
        alt_panel["INT"] = alt_panel["INT_RES_GDP"]
        alt_panel["D_SALE"] = (alt_panel["INT"] < 0).astype(float)
        alt_panel["INT_CRISIS"] = alt_panel["INT"] * alt_panel["CRISIS"]
        _, _, alt_summary = _fit_extension_models(alt_panel, suffix="_reserves_gdp")
        records.extend(_summary_records(alt_summary, "reserves_GDP"))

    _, alt_gfc_extension, _ = stage1.run_stage1(
        use_alternative_gfc=True, write_outputs=False
    )
    alt_gfc_extension.to_csv(OUTPUT_DIR / "stage1_on_off_alt_gfc.csv", index=False)
    alt_gfc_panel, _ = _period_exposure_panel("stage1_on_off_alt_gfc.csv")
    _, _, alt_gfc_summary = _fit_extension_models(alt_gfc_panel, suffix="_alternative_GFC")
    records.extend(_summary_records(alt_gfc_summary, "alternative_GFC"))
    result = pd.DataFrame(records)
    result.to_csv(OUTPUT_DIR / "robustness.csv", index=False)
    return result


def _summary_records(summary, check):
    if summary.empty:
        return [{"check": check, "g3": np.nan, "g3_p": np.nan,
                 "g1_plus_g3": np.nan, "g1_plus_g3_p": np.nan}]
    return [
        {"check": check, "g3": row.g3, "g3_p": row.g3_p,
         "g1_plus_g3": row.g1_plus_g3, "g1_plus_g3_p": row.g1_plus_g3_p}
        for row in summary.itertuples(index=False)
    ]


def run_stage2():
    setup_logging()
    replication_frame, replication_results = run_replication()
    extension, _ = _period_exposure_panel()
    main_fit, main_results, main_summary = _fit_extension_models(extension)
    if main_results.empty:
        extension_results = pd.DataFrame()
    else:
        extension_results = main_results.copy()
    extension_results.to_csv(OUTPUT_DIR / "stage2_extension.csv", index=False)
    main_summary["chow_joint_p"] = _chow_test(extension) if not extension.empty else np.nan
    split_summary = _run_split_model()
    split_summary.to_csv(OUTPUT_DIR / "stage2_gfc_covid_test.csv", index=False)
    significant_fit, significant_results, significant_summary = _fit_extension_models(
        extension, significant_only=True, suffix="_significant"
    )
    if not significant_results.empty:
        significant_results.to_csv(OUTPUT_DIR / "stage2_extension_significant.csv", index=False)
        significant_summary.to_csv(OUTPUT_DIR / "stage2_extension_significant_summary.csv", index=False)
    main_summary = pd.concat([main_summary, significant_summary], ignore_index=True)
    main_summary = main_summary.merge(
        split_summary[["gfc_equals_covid_p"]].head(1), how="cross"
    )
    main_summary.to_csv(OUTPUT_DIR / "stage2_interaction_summary.csv", index=False)
    run_robustness(main_summary.loc[main_summary["sample"] == "all"] if "sample" in main_summary else main_summary)
    logging.info(
        "Stage 2 complete: replication observations=%d, pooled firm-period observations=%d, "
        "main model g3=%s (p=%s)",
        len(replication_frame),
        len(extension),
        main_summary.iloc[0]["g3"] if not main_summary.empty else np.nan,
        main_summary.iloc[0]["g3_p"] if not main_summary.empty else np.nan,
    )
    return main_summary


if __name__ == "__main__":
    run_stage2()

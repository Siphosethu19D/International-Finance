"""Download and clean market, firm, intervention and control data.

This prepares the real-data inputs for the paper's monthly exchange-rate
exposure equation (Eq. 1) and the crisis-period extension. BIS and IMF are
attempted first; World Bank annual series are explicitly retained as an
annual-frequency fallback rather than being interpolated into monthly data.
"""

import json
import logging
import time
from pathlib import Path

import numpy as np
import pandas as pd
import requests
import yfinance as yf

from config import (
    BASE_DIR,
    BIS_API_BASES,
    BIS_DATAFLOW,
    BIS_MANUAL_URL,
    CLEAN_DIR,
    COUNTRIES,
    COVID_WINDOWS,
    END_DATE,
    END_DATE_EXCLUSIVE,
    FORCE_DOWNLOAD,
    GFC_WINDOWS,
    IMF_API_BASE,
    IMF_DATASET,
    MARKET_TICKERS,
    OUTPUT_DIR,
    RAW_DIR,
    START_DATE,
    WORLD_BANK_INDICATORS,
    WORLD_MARKET_TICKERS,
)

LOG_PATH = RAW_DIR / "download.log"
SESSION = requests.Session()
SESSION.headers.update({"User-Agent": "INFI9X2-assignment2/1.0"})


def setup_logging():
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    CLEAN_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        handlers=[logging.FileHandler(LOG_PATH, encoding="utf-8"), logging.StreamHandler()],
        force=True,
    )


def fetch_json(url, params=None):
    """Fetch and validate one JSON response, raising an actionable error."""
    response = SESSION.get(url, params=params, timeout=60)
    response.raise_for_status()
    return response.json(), response.url


def download_world_bank(indicator, output_path):
    """Fetch annual World Bank observations for all sample countries."""
    if output_path.exists() and not FORCE_DOWNLOAD:
        logging.info("CACHE World Bank %s: %s", indicator, output_path.name)
        return pd.read_csv(output_path)

    iso2 = ";".join(item["iso2"] for item in COUNTRIES.values())
    url = f"https://api.worldbank.org/v2/country/{iso2}/indicator/{indicator}"
    try:
        payload, request_url = fetch_json(
            url, {"format": "json", "per_page": 20000, "date": "2001:2025"}
        )
        if not isinstance(payload, list) or len(payload) < 2 or payload[1] is None:
            raise ValueError(f"World Bank returned no observations for {indicator}")
        rows = []
        for item in payload[1]:
            value = item.get("value")
            if value is None:
                continue
            rows.append(
                {
                    "country": item["country"]["value"],
                    "iso3": item["countryiso3code"],
                    "year": int(item["date"]),
                    "date": f"{item['date']}-12-31",
                    "indicator": indicator,
                    "value": float(value),
                }
            )
        frame = pd.DataFrame(rows)
        frame.to_csv(output_path, index=False)
        logging.info(
            "Downloaded World Bank %s: %d rows (%s)",
            indicator,
            len(frame),
            request_url,
        )
        return frame
    except Exception as exc:
        logging.error("World Bank download failed for %s: %s", indicator, exc)
        raise


def download_bis_neer():
    """Try the BIS SDMX CSV API and save its unmodified response when available."""
    raw_file = RAW_DIR / "bis_neer_raw.csv"
    manual_file = RAW_DIR / "bis_neer_manual.csv"
    clean_file = CLEAN_DIR / "neer_monthly.csv"
    if raw_file.exists() and clean_file.exists() and not FORCE_DOWNLOAD:
        logging.info("CACHE BIS NEER: %s", raw_file.name)
        return pd.read_csv(clean_file, parse_dates=["date"])

    def parse_bis_csv(source_path):
        raw = pd.read_csv(source_path)
        period_col = next(
            (c for c in raw.columns if c.lower() in {"time_period", "time", "period", "date"}),
            None,
        )
        value_col = next(
            (c for c in raw.columns if c.lower() in {"obs_value", "value", "observation"}),
            None,
        )
        area_col = next(
            (c for c in raw.columns if c.lower() in {"ref_area", "geo", "country", "area"}),
            None,
        )
        if period_col is None or value_col is None or area_col is None:
            raise ValueError(f"Unexpected BIS CSV columns: {list(raw.columns)}")
        raw[period_col] = pd.to_datetime(raw[period_col], errors="coerce")
        raw["iso2"] = raw[area_col].astype(str).str.upper()
        raw["neer"] = pd.to_numeric(raw[value_col], errors="coerce")
        out = raw.loc[raw["iso2"].isin([c["bis"] for c in COUNTRIES.values()])]
        out = out.rename(columns={period_col: "date"})[["iso2", "date", "neer"]].dropna()
        if out.empty:
            raise ValueError("BIS CSV contained no observations for the requested countries")
        out.to_csv(clean_file, index=False)
        return out

    if manual_file.exists() and not FORCE_DOWNLOAD:
        try:
            manual = parse_bis_csv(manual_file)
            logging.info("Loaded manually downloaded BIS NEER CSV: %d rows", len(manual))
            return manual
        except Exception as exc:
            logging.error("Could not parse manual BIS CSV %s: %s", manual_file, exc)

    errors = []
    # SDMX key dimensions: monthly frequency, nominal measure, broad basket.
    for api_base in BIS_API_BASES:
        url = f"{api_base}/{BIS_DATAFLOW}/M.N.B"
        try:
            response = SESSION.get(
                url,
                params={
                    "startPeriod": START_DATE[:7],
                    "endPeriod": END_DATE[:7],
                    "format": "csv",
                },
                headers={"Accept": "text/csv"},
                timeout=60,
            )
            response.raise_for_status()
            if not response.text.strip() or response.text.lstrip().startswith("<"):
                raise ValueError("BIS response was empty or not CSV")
            raw_file.write_text(response.text, encoding="utf-8")
            out = parse_bis_csv(raw_file)
            logging.info("Downloaded BIS broad nominal NEER: %d rows (%s)", len(out), response.url)
            return out
        except Exception as exc:
            errors.append(f"{api_base}: {exc}")
            logging.warning("BIS API attempt failed (%s): %s", api_base, exc)

    logging.error(
        "BIS NEER unavailable after %d attempts. Download the broad monthly nominal "
        "NEER CSV manually from %s, save it as %s, then rerun with FORCE_DOWNLOAD=False. "
        "Errors: %s",
        len(errors),
        BIS_MANUAL_URL,
        manual_file,
        " | ".join(errors),
    )
    return pd.DataFrame(columns=["iso2", "date", "neer"])


def download_imf_intervention():
    """Retry IMF IFS once with a browser-style User-Agent."""
    path = RAW_DIR / "imf_reserves_m2_raw.csv"
    status_path = RAW_DIR / "imf_retry_status.json"
    if path.exists() and not FORCE_DOWNLOAD:
        logging.info("CACHE IMF IFS: %s", path.name)
        return pd.read_csv(path), True
    if status_path.exists() and not FORCE_DOWNLOAD:
        status = json.loads(status_path.read_text(encoding="utf-8"))
        logging.info("CACHE IMF retry outcome: %s", status.get("status", "unknown"))
        return pd.DataFrame(), False

    url = f"{IMF_API_BASE}/{IMF_DATASET}/M.BR.RAFA_USD"
    try:
        response = SESSION.get(
            url,
            params={"startPeriod": START_DATE[:7], "endPeriod": END_DATE[:7], "detail": "dataonly"},
            headers={
                "Accept": "text/csv",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36",
            },
            timeout=30,
        )
        response.raise_for_status()
        if not response.text.strip() or response.text.lstrip().startswith("<"):
            raise ValueError("IMF returned no CSV observations")
        path.write_text(response.text, encoding="utf-8")
        raise ValueError("IMF response received but its series schema cannot yet be validated")
    except Exception as exc:
        logging.warning("IMF monthly retry failed; keep annual World Bank proxy: %s", exc)
        status_path.write_text(
            json.dumps({"status": "annual_world_bank_fallback", "reason": str(exc)}, indent=2),
            encoding="utf-8",
        )
    logging.warning(
        "IMF IFS monthly reserves/M2 was not parsed; using World Bank annual fallback. "
        "The single browser-header retry was unsuccessful or had an unverified schema."
    )
    return pd.DataFrame(), False


def get_world_bank_inputs():
    """Download World Bank series once each and retain their original frequency."""
    frames = {}
    for name, code in WORLD_BANK_INDICATORS.items():
        dest = RAW_DIR / f"world_bank_{name}.csv"
        frames[name] = download_world_bank(code, dest)
    return frames


def build_intervention(wb_frames):
    """Construct change in FX reserves/M2; World Bank fallback is annual."""
    reserves = wb_frames["reserves_usd"][["iso3", "year", "value"]].rename(
        columns={"value": "reserves_usd"}
    )
    money = wb_frames["broad_money_lcu"][["iso3", "year", "value"]].rename(
        columns={"value": "broad_money_lcu"}
    )
    rate = wb_frames["exchange_rate_lcu_per_usd"][["iso3", "year", "value"]].rename(
        columns={"value": "exchange_rate_lcu_per_usd"}
    )
    frame = reserves.merge(money, on=["iso3", "year"], how="inner")
    frame = frame.merge(rate, on=["iso3", "year"], how="inner")
    frame["reserves_m2_ratio"] = (
        frame["reserves_usd"] * frame["exchange_rate_lcu_per_usd"] / frame["broad_money_lcu"]
    )
    # Intervention proxy: INT_t = (Reserves_USD_t * LCU_per_USD_t / M2_LCU_t) - ratio_(t-1).
    frame = frame.sort_values(["iso3", "year"])
    frame["intervention"] = frame.groupby("iso3")["reserves_m2_ratio"].diff()
    frame["date"] = pd.to_datetime(frame["year"].astype(str) + "-12-31")
    frame["frequency"] = "A"
    frame["source"] = "World Bank annual fallback"
    frame = frame.dropna(subset=["intervention"])
    frame.to_csv(CLEAN_DIR / "intervention_annual.csv", index=False)
    if "gdp_lcu" in wb_frames:
        gdp = wb_frames["gdp_lcu"][["iso3", "year", "value"]].rename(columns={"value": "gdp_lcu"})
        alt = frame.merge(gdp, on=["iso3", "year"], how="inner")
        alt["reserves_gdp_ratio"] = (
            alt["reserves_usd"] * alt["exchange_rate_lcu_per_usd"] / alt["gdp_lcu"]
        )
        alt["intervention_reserves_gdp"] = alt.groupby("iso3")["reserves_gdp_ratio"].diff()
        alt = alt.dropna(subset=["intervention_reserves_gdp"])
        alt.to_csv(CLEAN_DIR / "intervention_reserves_gdp_annual.csv", index=False)
        logging.info("Built annual change in reserves/GDP proxy: %d country-years", len(alt))
    logging.info("Built annual World Bank intervention proxy: %d country-years", len(frame))
    return frame


def build_country_controls(wb_frames):
    controls = []
    for variable in ("openness", "broad_money_gdp", "gdp_per_capita_usd"):
        frame = wb_frames[variable][["country", "iso3", "year", "date", "value"]].copy()
        frame["variable"] = variable
        controls.append(frame)
    result = pd.concat(controls, ignore_index=True)
    result.to_csv(CLEAN_DIR / "country_controls_annual.csv", index=False)
    logging.info("Built annual country controls: %d rows", len(result))
    return result


def download_yahoo_prices(tickers, file_stem):
    """Download monthly adjusted prices, cache raw responses and return long data."""
    raw_path = RAW_DIR / f"{file_stem}_raw.csv"
    clean_path = CLEAN_DIR / f"{file_stem}_monthly.csv"
    if raw_path.exists() and clean_path.exists() and not FORCE_DOWNLOAD:
        logging.info("CACHE Yahoo prices: %s", raw_path.name)
        cached = pd.read_csv(clean_path, parse_dates=["date"])
        return (
            cached[["ticker", "date", "adjusted_close"]]
            .drop_duplicates(["ticker", "date"], keep="last")
            .copy()
        )

    symbols = list(dict.fromkeys(tickers))
    if not symbols:
        return pd.DataFrame(columns=["ticker", "date", "adjusted_close"])
    try:
        prices = yf.download(
            tickers=symbols,
            start=START_DATE,
            end=END_DATE_EXCLUSIVE,
            interval="1mo",
            auto_adjust=True,
            group_by="ticker",
            progress=False,
            threads=True,
            multi_level_index=True,
        )
        if prices is None or prices.empty:
            raise ValueError("Yahoo Finance returned an empty price table")
        prices.to_csv(raw_path)
        records = []
        if isinstance(prices.columns, pd.MultiIndex):
            first_level = set(prices.columns.get_level_values(0))
            for ticker in symbols:
                if ticker not in first_level:
                    logging.warning("Yahoo price ticker unavailable: %s", ticker)
                    continue
                ticker_data = prices[ticker]
                close_col = "Close" if "Close" in ticker_data.columns else None
                if close_col is None:
                    logging.warning("Yahoo returned no adjusted close for %s", ticker)
                    continue
                values = ticker_data[close_col].dropna()
                records.extend(
                    {"ticker": ticker, "date": date, "adjusted_close": float(value)}
                    for date, value in values.items()
                )
        else:
            ticker = symbols[0]
            close_col = "Close" if "Close" in prices.columns else None
            if close_col:
                records.extend(
                    {"ticker": ticker, "date": date, "adjusted_close": float(value)}
                    for date, value in prices[close_col].dropna().items()
                )
        frame = pd.DataFrame(records)
        if frame.empty:
            raise ValueError("Yahoo response contained no usable Close observations")
        frame["date"] = pd.to_datetime(frame["date"]).dt.to_period("M").dt.to_timestamp("M")
        frame = frame.drop_duplicates(["ticker", "date"]).sort_values(["ticker", "date"])
        frame.to_csv(clean_path, index=False)
        logging.info("Downloaded Yahoo %s: %d symbols, %d observations", file_stem, len(frame["ticker"].unique()), len(frame))
        return frame
    except Exception as exc:
        logging.error("Yahoo price download failed for %s: %s", file_stem, exc)
        return pd.DataFrame(columns=["ticker", "date", "adjusted_close"])


def recover_missing_firms(firms, prices):
    """Try one real Yahoo alternative for every listed firm missing from the cache."""
    alternatives = {
        "EMBR3.SA": "EMBJ3.SA",
        "JBSS3.SA": "JBS",
        "CLH.CL": "",
        "CORAREI1.LM": "CORAREI1.LM",
        "ALI.PS": "AYALF",
        "SM.PS": "SVTMY",
        "AC.PS": "AYALY",
        "JFC.PS": "JBFCF",
        "ICT.PS": "ICTEF",
        "TEL.PS": "PHI",
        "URC.PS": "UVRBY",
        "SMPH.PS": "SMPH.PS",
        "GTCAP.PS": "GTCPY",
        "AP.PS": "ABTZY",
    }
    existing = set(prices["ticker"].unique()) if not prices.empty else set()
    missing = firms.loc[~firms["ticker"].isin(existing)].copy()
    if missing.empty:
        logging.info("All listed firm tickers have cached prices; no alternative requests needed")
        return firms, prices, pd.DataFrame()

    attempts = []
    recovered = []
    for row in missing.itertuples(index=False):
        alternative = alternatives.get(row.ticker)
        status = "dropped_no_alternative"
        details = "No suitable alternative identified"
        if alternative:
            alt_prices = download_yahoo_prices([alternative], f"firm_alternative_{alternative.replace('.', '_')}")
            if not alt_prices.empty:
                alt_prices["listed_ticker"] = row.ticker
                recovered.append(
                    alt_prices.assign(
                        ticker=alternative,
                        name=row.name,
                        country=row.country,
                        sector=row.sector,
                    )[["ticker", "date", "adjusted_close", "name", "country", "sector", "listed_ticker"]]
                )
                status = "recovered_with_alternative"
                details = f"Alternative {alternative} returned {len(alt_prices)} price observations"
                row_mask = firms["ticker"] == row.ticker
                firms.loc[row_mask, "ticker"] = alternative
                firms.loc[row_mask, "name"] = row.name
                firms.loc[row_mask, "country"] = row.country
                firms.loc[row_mask, "sector"] = row.sector
            else:
                status = "dropped_alternative_failed"
                details = f"Alternative {alternative} returned no price observations"
        logging.info("Firm ticker attempt %s (%s): %s; %s", row.ticker, row.country, status, details)
        attempts.append(
            {
                "firm": row.ticker,
                "name": row.name,
                "country": row.country,
                "primary_ticker": row.ticker,
                "alternative_ticker": alternative or "",
                "status": status,
                "details": details,
            }
        )

    if recovered:
        recovered_frame = pd.concat(recovered, ignore_index=True)
        prices = pd.concat([prices, recovered_frame.drop(columns=["listed_ticker"])], ignore_index=True)
    failures = pd.DataFrame(attempts).query("status != 'recovered_with_alternative'")
    if not failures.empty:
        dropped_path = OUTPUT_DIR / "dropped_firms_log.csv"
        failures.to_csv(dropped_path, index=False)
    failed_primary = {
        row["primary_ticker"]
        for row in attempts
        if row["status"] != "recovered_with_alternative"
    }
    firms = firms.loc[~firms["ticker"].isin(failed_primary)].copy()
    firms.to_csv(BASE_DIR / "tickers.csv", index=False)
    return firms, prices, pd.DataFrame(attempts)


def build_firm_coverage(firms, prices, calendar):
    """Screen observed firm returns by window without filling any missing months."""
    prices = prices.sort_values(["ticker", "date"]).copy()
    prices["date"] = pd.to_datetime(prices["date"])
    prices = prices.loc[prices["adjusted_close"] > 0]
    prices["return"] = prices.groupby("ticker")["adjusted_close"].transform(
        lambda series: np.log(series / series.shift(1))
    )
    period_defs = {
        "replication": ("2001-04", "2017-03", 0.80),
        "extension": ("2001-04", "2025-12", 0.80),
        "GFC": (GFC_WINDOWS["primary"][0], GFC_WINDOWS["primary"][1], 0.80),
    }
    rows = []
    for firm in firms.itertuples(index=False):
        firm_returns = prices.loc[prices["ticker"] == firm.ticker, ["date", "return"]].dropna()
        record = {"firm": firm.ticker, "name": firm.name, "country": firm.country}
        for window, (start, end, threshold) in period_defs.items():
            start_period, end_period = pd.Period(start, "M"), pd.Period(end, "M")
            expected = len(pd.period_range(start_period, end_period, freq="M")) - 1
            observed_mask = firm_returns["date"].dt.to_period("M").between(start_period, end_period)
            n_obs = int(observed_mask.sum())
            record[f"{window}_n_obs"] = n_obs
            record[f"{window}_required"] = int(np.ceil(expected * threshold))
            record[f"{window}_pass"] = bool(expected > 0 and n_obs >= np.ceil(expected * threshold))

        covid_periods = calendar.loc[
            (calendar["country"] == firm.country) & (calendar["covid"] == 1), "month"
        ].tolist()
        covid_months = {pd.Period(value, "M") for value in covid_periods}
        covid_returns = firm_returns.loc[
            firm_returns["date"].dt.to_period("M").isin(covid_months)
        ]
        record["COVID_n_obs"] = int(len(covid_returns))
        record["COVID_required"] = 10
        record["COVID_pass"] = bool(len(covid_returns) >= 10)
        rows.append(record)

    frame = pd.DataFrame(rows)
    frame.to_csv(CLEAN_DIR / "firm_coverage.csv", index=False)
    failure_rows = []
    for window in ("replication", "extension", "GFC", "COVID"):
        failed = frame.loc[~frame[f"{window}_pass"]]
        for row in failed.itertuples(index=False):
            failure_rows.append(
                {
                    "firm": row.firm,
                    "name": row.name,
                    "country": row.country,
                    "primary_ticker": row.firm,
                    "alternative_ticker": "",
                    "status": f"dropped_coverage_{window}",
                    "details": (
                        f"{getattr(row, f'{window}_n_obs')} observed returns; "
                        f"{getattr(row, f'{window}_required')} required"
                    ),
                }
            )
    if failure_rows:
        drop_path = OUTPUT_DIR / "dropped_firms_log.csv"
        current = pd.read_csv(drop_path) if drop_path.exists() else pd.DataFrame()
        combined = pd.concat([current, pd.DataFrame(failure_rows)], ignore_index=True)
        combined.drop_duplicates(["firm", "status"], keep="last").to_csv(drop_path, index=False)
    kept_by_country = []
    for window in ("replication", "extension", "GFC", "COVID"):
        counts = (
            frame.loc[frame[f"{window}_pass"]]
            .groupby("country")["firm"]
            .nunique()
            .reindex(COUNTRIES, fill_value=0)
        )
        for country, count in counts.items():
            excluded = count < 3
            logging.info(
                "%s firms kept: %s=%d%s",
                window,
                country,
                count,
                " [EXCLUDED: fewer than 3 firms]" if excluded else "",
            )
            kept_by_country.append(
                {"window": window, "country": country, "firms_kept": count, "excluded": excluded}
            )
        low = counts[counts < 3]
        if not low.empty:
            logging.warning(
                "Country exclusion for %s window (fewer than 3 firms): %s",
                window,
                ", ".join(f"{country} ({count})" for country, count in low.items()),
            )
    pd.DataFrame(kept_by_country).to_csv(CLEAN_DIR / "firm_counts_by_window.csv", index=False)
    logging.info("Saved firm return coverage screen: %s", CLEAN_DIR / "firm_coverage.csv")
    return frame


def save_intervention_sources(intervention):
    source = intervention[["iso3", "source"]].drop_duplicates()
    names = {metadata["iso3"]: country for country, metadata in COUNTRIES.items()}
    source["country"] = source["iso3"].map(names)
    source.to_csv(CLEAN_DIR / "intervention_source.csv", index=False)
    logging.info("Saved country intervention source labels: %s", CLEAN_DIR / "intervention_source.csv")


def download_firm_info(firms):
    """Best-effort Yahoo sector and market-cap metadata for each listed firm."""
    path = RAW_DIR / "yahoo_firm_info.json"
    cleaned_path = CLEAN_DIR / "firm_info.csv"
    if cleaned_path.exists() and not FORCE_DOWNLOAD:
        cached = pd.read_csv(cleaned_path)
        info_by_ticker = {
            row["ticker"]: row for row in cached.to_dict("records")
        }
    else:
        info_by_ticker = {}
    records = []
    for row in firms.itertuples(index=False):
        if row.ticker in info_by_ticker:
            record = info_by_ticker[row.ticker].copy()
            record.update(
                {
                    "ticker": row.ticker,
                    "name": row.name,
                    "country": row.country,
                    "sector_listed": row.sector,
                }
            )
            records.append(record)
            continue
        record = {
            "ticker": row.ticker,
            "name": row.name,
            "country": row.country,
            "sector_listed": row.sector,
            "sector_yahoo": np.nan,
            "industry": np.nan,
            "market_cap": np.nan,
            "info_source": "Yahoo Finance",
        }
        try:
            info = yf.Ticker(row.ticker).info
            record["sector_yahoo"] = info.get("sector")
            record["industry"] = info.get("industry")
            record["market_cap"] = info.get("marketCap")
            logging.info("Firm metadata %s: received", row.ticker)
        except Exception as exc:
            logging.warning("Firm metadata unavailable for %s: %s", row.ticker, exc)
        records.append(record)
        time.sleep(0.05)
    frame = pd.DataFrame(records)
    path.write_text(json.dumps(records, indent=2, default=str), encoding="utf-8")
    frame.to_csv(cleaned_path, index=False)
    return frame


def create_crisis_calendar():
    months = pd.period_range(START_DATE[:7], END_DATE[:7], freq="M")
    gfc = GFC_WINDOWS["alternative" if __import__("config").USE_ALTERNATIVE_GFC else "primary"]
    records = []
    for country in COUNTRIES:
        covid_start, covid_end = COVID_WINDOWS[country]
        for month in months:
            key = str(month)
            is_gfc = gfc[0] <= key <= gfc[1]
            is_covid = covid_start <= key <= covid_end
            records.append(
                {
                    "country": country,
                    "month": key,
                    "gfc": int(is_gfc),
                    "covid": int(is_covid),
                    "crisis": int(is_gfc or is_covid),
                    "period": "ON" if is_gfc or is_covid else "OFF",
                }
            )
    frame = pd.DataFrame(records)
    frame.to_csv(CLEAN_DIR / "crisis_calendar.csv", index=False)
    logging.info("Created crisis calendar: %d country-month rows", len(frame))
    return frame


def main():
    setup_logging()
    logging.info("Starting download and clean stage")
    logging.info("Sample period: %s through %s; monthly market data", START_DATE, END_DATE)
    logging.info("Cache mode: %s", "FORCE_DOWNLOAD" if FORCE_DOWNLOAD else "use existing raw downloads")

    neer = download_bis_neer()
    firms = pd.read_csv(BASE_DIR / "tickers.csv")
    firm_prices = download_yahoo_prices(firms["ticker"].tolist(), "firm_prices")
    firms, firm_prices, ticker_attempts = recover_missing_firms(firms, firm_prices)
    if not ticker_attempts.empty:
        attempt_log = OUTPUT_DIR / "dropped_firms_log.csv"
        current = pd.read_csv(attempt_log) if attempt_log.exists() else pd.DataFrame()
        current = pd.concat([current, ticker_attempts], ignore_index=True).drop_duplicates(
            subset=["firm", "primary_ticker", "alternative_ticker"], keep="last"
        )
        current.to_csv(attempt_log, index=False)

    market_tickers = [ticker for options in MARKET_TICKERS.values() for ticker in options]
    market_tickers.extend(WORLD_MARKET_TICKERS)
    market_prices = download_yahoo_prices(market_tickers, "market_prices")
    if not market_prices.empty:
        market_prices.to_csv(CLEAN_DIR / "market_index_monthly.csv", index=False)
    if not firm_prices.empty:
        firm_prices = firm_prices.drop_duplicates(["ticker", "date"], keep="last")
        firm_prices = firm_prices.merge(firms[["ticker", "name", "country", "sector"]], on="ticker", how="left")
        firm_prices.to_csv(CLEAN_DIR / "firm_prices_monthly.csv", index=False)

    download_firm_info(firms)
    imf_frame, imf_success = download_imf_intervention()
    if not imf_success:
        wb_frames = get_world_bank_inputs()
        intervention = build_intervention(wb_frames)
        controls = build_country_controls(wb_frames)
        used_sources = intervention[["country" if "country" in intervention else "iso3", "source"]].drop_duplicates()
        logging.info("Intervention sources by country: %s", used_sources.to_dict("records"))
    else:
        logging.info("IMF response cached for review; no unverified series parsing was performed")
        wb_frames = get_world_bank_inputs()
        intervention = build_intervention(wb_frames)
        controls = build_country_controls(wb_frames)

    save_intervention_sources(intervention)
    calendar = create_crisis_calendar()
    coverage = build_firm_coverage(firms, firm_prices, calendar)
    logging.info(
        "Download stage complete: firms listed=%d, firm price tickers=%d, market price tickers=%d, "
        "BIS NEER rows=%d, intervention observations=%d, country-control rows=%d",
        len(firms),
        firm_prices["ticker"].nunique() if not firm_prices.empty else 0,
        market_prices["ticker"].nunique() if not market_prices.empty else 0,
        len(neer),
        len(intervention),
        len(controls),
    )
    logging.info("Review download log: %s", LOG_PATH)


if __name__ == "__main__":
    main()

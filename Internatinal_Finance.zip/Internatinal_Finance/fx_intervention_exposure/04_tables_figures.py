"""Report estimated Eq. (1), Eq. (4-6) and crisis interaction results as tables and figures."""

import logging
from datetime import date

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from config import (
    BIS_MANUAL_URL,
    CLEAN_DIR,
    COUNTRIES,
    COVID_WINDOWS,
    GFC_WINDOWS,
    OUTPUT_DIR,
    WORLD_BANK_INDICATORS,
)

LOG_PATH = OUTPUT_DIR / "stage4.log"


def setup_logging():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        handlers=[logging.FileHandler(LOG_PATH, encoding="utf-8"), logging.StreamHandler()],
        force=True,
    )


def _star(p_value):
    if pd.isna(p_value):
        return ""
    if p_value < 0.01:
        return "***"
    if p_value < 0.05:
        return "**"
    if p_value < 0.10:
        return "*"
    return ""


def _format_estimate(value, p_value):
    if pd.isna(value):
        return ""
    return f"{value:.4f}{_star(p_value)}"


def _format_regression_table(path, output_name, equation=None):
    if not path.exists():
        pd.DataFrame().to_csv(OUTPUT_DIR / output_name, index=False)
        return pd.DataFrame()
    frame = pd.read_csv(path)
    if equation is not None and "equation" in frame.columns:
        frame = frame.loc[frame["equation"] == equation].copy()
    if frame.empty:
        frame.to_csv(OUTPUT_DIR / output_name, index=False)
        return frame
    frame["estimate_stars"] = frame.apply(
        lambda row: _format_estimate(row.get("coef"), row.get("p_hc1")), axis=1
    )
    if "se_hc1" not in frame:
        frame["se_hc1"] = np.nan
    if "se_cluster" not in frame:
        frame["se_cluster"] = np.nan
    frame["se_in_brackets"] = frame["se_hc1"].map(
        lambda value: f"[{value:.4f}]" if pd.notna(value) else ""
    )
    frame["country_cluster_se_in_brackets"] = frame["se_cluster"].map(
        lambda value: f"[{value:.4f}]" if pd.notna(value) else ""
    )
    cols = [
        col for col in (
            "model", "sample", "equation", "term", "estimate_stars",
            "se_in_brackets", "country_cluster_se_in_brackets",
            "p_hc1", "p_cluster", "n_obs", "adj_r2", "cluster_groups",
            "cluster_note",
        ) if col in frame.columns
    ]
    frame[cols].to_csv(OUTPUT_DIR / output_name, index=False)
    return frame


def create_tables():
    adf_path = OUTPUT_DIR / "stage1_adf.csv"
    if adf_path.exists():
        adf = pd.read_csv(adf_path)
        stats = (
            adf.groupby(["country", "variable"], dropna=False)
            .agg(
                n_series=("firm", "nunique"),
                mean_adf_stat=("adf_stat", "mean"),
                median_adf_p=("p_value", "median"),
                n_stationary_5pct=("p_value", lambda s: int((s < 0.05).sum())),
                n_tests=("p_value", "count"),
            )
            .reset_index()
        )
        stats.to_csv(OUTPUT_DIR / "Table1A_country_stats.csv", index=False)

    for equation, dest in (
        (4, "Table3_eq4.csv"),
        (5, "Table4_eq5.csv"),
        (6, "Table5_eq6.csv"),
    ):
        _format_regression_table(
            OUTPUT_DIR / "stage2_replication.csv", dest, equation=equation
        )

    exposure_path = OUTPUT_DIR / "Table2_exposure_replication.csv"
    if exposure_path.exists():
        pd.read_csv(exposure_path).to_csv(OUTPUT_DIR / "Table2_exposure_replication.csv", index=False)
    extension_path = OUTPUT_DIR / "Table2b_exposure_on_off.csv"
    if extension_path.exists():
        pd.read_csv(extension_path).to_csv(OUTPUT_DIR / "Table2b_exposure_on_off.csv", index=False)

    summary_path = OUTPUT_DIR / "stage2_interaction_summary.csv"
    if summary_path.exists():
        summary = pd.read_csv(summary_path)
        summary["g3_stars"] = summary.apply(
            lambda row: _format_estimate(row.get("g3"), row.get("g3_p")), axis=1
        )
        summary["g1_plus_g3_stars"] = summary.apply(
            lambda row: _format_estimate(row.get("g1_plus_g3"), row.get("g1_plus_g3_p")), axis=1
        )
        summary.to_csv(OUTPUT_DIR / "Table6_crisis_interaction.csv", index=False)
    split = OUTPUT_DIR / "stage2_gfc_covid_test.csv"
    if split.exists():
        pd.read_csv(split).to_csv(OUTPUT_DIR / "Table7_gfc_vs_covid.csv", index=False)
    robustness = OUTPUT_DIR / "robustness.csv"
    if robustness.exists():
        frame = pd.read_csv(robustness)
        frame["g3_stars"] = frame.apply(lambda row: _format_estimate(row.get("g3"), row.get("g3_p")), axis=1)
        frame["g1_plus_g3_stars"] = frame.apply(
            lambda row: _format_estimate(row.get("g1_plus_g3"), row.get("g1_plus_g3_p")), axis=1
        )
        frame.to_csv(OUTPUT_DIR / "Table8_robustness.csv", index=False)

    data_description = build_data_description()
    data_description.to_csv(OUTPUT_DIR / "DataDescription.csv", index=False)
    return data_description


def build_data_description():
    rows = []
    definitions = [
        ("NEER", "BIS", "Monthly", "Broad nominal effective exchange rate index; appreciation is positive",
         "https://data.bis.org/topics/EER", "neer_monthly.csv", "neer"),
        ("Firm adjusted close", "Yahoo Finance", "Monthly", "Adjusted close; no historical backfill",
         "https://finance.yahoo.com/", "firm_prices_monthly.csv", "adjusted_close"),
        ("Local market adjusted close", "Yahoo Finance", "Monthly", "Local equity market benchmark; actual ticker start dates retained",
         "https://finance.yahoo.com/", "market_index_monthly.csv", "adjusted_close"),
        ("Intervention proxy", "World Bank", "Annual", "Change in reserves excluding gold / broad money",
         "https://api.worldbank.org/v2/", "intervention_annual.csv", "intervention"),
        ("Alternative intervention proxy", "World Bank", "Annual", "Change in reserves excluding gold / GDP",
         "https://api.worldbank.org/v2/", "intervention_reserves_gdp_annual.csv", "intervention_reserves_gdp"),
        ("Trade openness", "World Bank", "Annual", WORLD_BANK_INDICATORS["openness"],
         "https://api.worldbank.org/v2/", "country_controls_annual.csv", "openness"),
        ("Broad money / GDP", "World Bank", "Annual", WORLD_BANK_INDICATORS["broad_money_gdp"],
         "https://api.worldbank.org/v2/", "country_controls_annual.csv", "broad_money_gdp"),
        ("GDP per capita", "World Bank", "Annual; log in regressions", WORLD_BANK_INDICATORS["gdp_per_capita_usd"],
         "https://api.worldbank.org/v2/", "country_controls_annual.csv", "gdp_per_capita_usd"),
    ]
    for variable, source, frequency, definition, url, filename, column in definitions:
        path = CLEAN_DIR / filename
        if not path.exists():
            n, period = 0, ""
        else:
            frame = pd.read_csv(path)
            if column == "neer":
                n = int(frame[column].notna().sum())
            elif column == "adjusted_close":
                n = int(frame[column].notna().sum())
            elif column in frame:
                n = int(frame[column].notna().sum())
            elif "value" in frame:
                n = int(frame["value"].notna().sum())
            else:
                n = len(frame)
            date_col = "date" if "date" in frame else None
            if date_col:
                dates = pd.to_datetime(frame[date_col], errors="coerce").dropna()
                period = (
                    f"{dates.min().date()} to {dates.max().date()}" if not dates.empty else ""
                )
            elif "year" in frame:
                period = f"{frame['year'].min()} to {frame['year'].max()}"
            else:
                period = ""
        rows.append(
            {
                "variable": variable, "source": source, "URL": url,
                "frequency": frequency, "sample_period": period,
                "N_nonmissing": n, "definition_or_code": definition,
            }
        )
    sources = pd.read_csv(CLEAN_DIR / "intervention_source.csv")
    names = {v["iso3"]: name for name, v in COUNTRIES.items()}
    for row in sources.itertuples(index=False):
        rows.append(
            {
                "variable": f"Intervention source for {names.get(row.iso3, row.iso3)}",
                "source": row.source, "URL": "https://api.worldbank.org/v2/",
                "frequency": "Annual", "sample_period": "2002–2025 or latest available",
                "N_nonmissing": np.nan, "definition_or_code": "World Bank fallback; not interpolated",
            }
        )
    return pd.DataFrame(rows)


def _shade_crisis(ax, country):
    gfc_start, gfc_end = GFC_WINDOWS["primary"]
    ax.axvspan(pd.Period(gfc_start, "M").to_timestamp(), pd.Period(gfc_end, "M").to_timestamp("M"),
               color="orange", alpha=0.18, label="GFC ON")
    covid_start, covid_end = COVID_WINDOWS[country]
    ax.axvspan(pd.Period(covid_start, "M").to_timestamp(),
               pd.Period(covid_end, "M").to_timestamp("M"),
               color="red", alpha=0.12, label="COVID ON")


def create_figures():
    neer = pd.read_csv(CLEAN_DIR / "neer_monthly.csv", parse_dates=["date"])
    iso_to_country = {v["bis"]: k for k, v in COUNTRIES.items()}
    neer["country"] = neer["iso2"].map(iso_to_country)
    for country, frame in neer.groupby("country"):
        fig, ax = plt.subplots(figsize=(10, 4.5))
        ax.plot(frame["date"], frame["neer"], linewidth=1.2)
        _shade_crisis(ax, country)
        ax.set(title=f"{country} broad nominal NEER", ylabel="Index", xlabel="Month")
        ax.legend(loc="best", fontsize=8)
        fig.tight_layout()
        fig.savefig(OUTPUT_DIR / f"neer_{country.lower().replace(' ', '_')}.png", dpi=160)
        plt.close(fig)

    intervention = pd.read_csv(CLEAN_DIR / "intervention_annual.csv", parse_dates=["date"])
    iso3_to_country = {v["iso3"]: k for k, v in COUNTRIES.items()}
    intervention["country"] = intervention["iso3"].map(iso3_to_country)
    for country, frame in intervention.groupby("country"):
        fig, ax = plt.subplots(figsize=(10, 4.5))
        ax.axhline(0, color="black", linewidth=0.7)
        ax.plot(frame["date"], frame["intervention"], marker="o", linewidth=1)
        _shade_crisis(ax, country)
        ax.set(title=f"{country} annual change in reserves/M2", ylabel="Intervention proxy", xlabel="Year")
        ax.legend(loc="best", fontsize=8)
        fig.tight_layout()
        fig.savefig(OUTPUT_DIR / f"intervention_{country.lower().replace(' ', '_')}.png", dpi=160)
        plt.close(fig)

    exposure = pd.read_csv(OUTPUT_DIR / "stage1_on_off.csv")
    exposure = exposure.loc[exposure["model"] == "crisis_on_off"]
    means = exposure.groupby(["country", "period"])["abs_beta"].mean().unstack()
    fig, ax = plt.subplots(figsize=(12, 6))
    periods = [p for p in ("OFF", "ON") if p in means.columns]
    if periods:
        means[periods].plot(kind="bar", ax=ax)
    ax.set(title="Mean absolute exposure by period", ylabel="Mean |beta|", xlabel="Country")
    ax.legend(title="Period")
    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / "mean_abs_beta_off_on.png", dpi=160)
    plt.close(fig)

    split = pd.read_csv(OUTPUT_DIR / "stage1_on_off.csv")
    split = split.loc[split["model"] == "gfc_covid"]
    split_means = split.groupby(["country", "period"])["abs_beta"].mean().unstack()
    fig, ax = plt.subplots(figsize=(12, 6))
    periods = [p for p in ("GFC", "COVID") if p in split_means.columns]
    if periods:
        split_means[periods].plot(kind="bar", ax=ax)
    ax.set(title="Mean absolute exposure: GFC vs COVID", ylabel="Mean |beta|", xlabel="Country")
    ax.legend(title="Period")
    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / "mean_abs_beta_gfc_covid.png", dpi=160)
    plt.close(fig)

    summary_path = OUTPUT_DIR / "stage2_interaction_summary.csv"
    summary = pd.read_csv(summary_path) if summary_path.exists() else pd.DataFrame()
    if not summary.empty:
        row = summary.iloc[0]
        estimates = [row.get("g1", np.nan), row.get("g1_plus_g3", np.nan)]
        errors = [row.get("g1_se", np.nan), row.get("g1_plus_g3_se", np.nan)]
        labels = ["OFF effect (g1)", "ON effect (g1 + g3)"]
        fig, ax = plt.subplots(figsize=(7, 4.5))
        x = np.arange(2)
        ax.errorbar(x, estimates, yerr=1.645 * np.asarray(errors), fmt="o", capsize=5)
        ax.axhline(0, color="black", linewidth=0.7)
        ax.set_xticks(x, labels)
        ax.set(title="Intervention effect with 90% confidence intervals", ylabel="Estimated coefficient")
        fig.tight_layout()
        fig.savefig(OUTPUT_DIR / "coefficient_plot_off_vs_on.png", dpi=160)
        plt.close(fig)


def _number(value, digits=4):
    return f"{value:.{digits}f}" if pd.notna(value) else "not estimable"


def write_results_summary():
    lines = [
        "# Results summary",
        "",
        "All statements below are calculated from the estimates saved in this output folder. "
        "No coefficient or significance result from either cited paper is hard-coded.",
        "",
    ]
    table_paths = [
        ("Table 1A", "Table1A_country_stats.csv"),
        ("Table 2", "Table2_exposure_replication.csv"),
        ("Table 2b", "Table2b_exposure_on_off.csv"),
        ("Table 3", "Table3_eq4.csv"),
        ("Table 4", "Table4_eq5.csv"),
        ("Table 5", "Table5_eq6.csv"),
        ("Table 6", "Table6_crisis_interaction.csv"),
        ("Table 7", "Table7_gfc_vs_covid.csv"),
        ("Table 8", "Table8_robustness.csv"),
        ("DataDescription", "DataDescription.csv"),
    ]
    for label, filename in table_paths:
        path = OUTPUT_DIR / filename
        lines.append(f"## {label}")
        if not path.exists():
            lines.append("No estimates were produced for this table.")
            lines.append("")
            continue
        frame = pd.read_csv(path)
        if frame.empty:
            lines.append("The required source estimates were not available for this table.")
        elif label == "Table 1A":
            summaries = []
            for variable, group in frame.groupby("variable"):
                tested = int(group["n_tests"].sum())
                stationary = int(group["n_stationary_5pct"].sum())
                summaries.append(f"{variable}: {stationary}/{tested} tests reject at 5%")
            lines.append("ADF results: " + "; ".join(summaries) + ".")
        elif label == "Table 2":
            total = frame.loc[frame["country"] == "Total"]
            if total.empty:
                lines.append("No total-row exposure summary was available.")
            else:
                row = total.iloc[0]
                lines.append(
                    f"Across {int(row['n_firms'])} firms, {int(row['n_sig10'])} "
                    f"({row['pct_sig10']:.1f}%) have significant exposure at 10%. "
                    f"The mean signed beta is {_number(row['mean_beta'])}, mean |beta| is "
                    f"{_number(row['mean_abs_beta'])}, and the significant signs are "
                    f"{int(row['n_sig_positive'])} positive and {int(row['n_sig_negative'])} negative."
                )
        elif label == "Table 2b":
            total = frame.loc[frame["country"] == "Total"]
            if total.empty:
                lines.append("No period total-row exposure summaries were available.")
            else:
                descriptions = [
                    f"{row.period}: mean |beta|={_number(row.mean_abs_beta)}, "
                    f"significant={_number(row.pct_sig10, 1)}%, "
                    f"Wald rejections={_number(row.pct_wald_reject, 1)}%"
                    for row in total.itertuples(index=False)
                ]
                lines.append("; ".join(descriptions) + ".")
        elif label in ("Table 3", "Table 4", "Table 5"):
            interventions = frame.loc[frame["term"] == "INT"]
            if interventions.empty:
                lines.append("The intervention coefficient was not estimable after exclusions.")
            else:
                estimates = []
                for sample, group in interventions.groupby("sample", sort=False):
                    best = group.iloc[0]
                    estimates.append(
                        f"{sample}: INT={best.get('estimate_stars', '')} "
                        f"(HC1 p={_number(best.get('p_hc1'), 3)}, N={int(best.get('n_obs', 0))})"
                    )
                unavailable = frame.loc[frame["term"] == "MODEL_STATUS", "sample"].unique()
                if len(unavailable):
                    estimates.extend(f"{sample}: not estimable (too few observations)" for sample in unavailable)
                lines.append(
                    "Intervention estimates: " + "; ".join(estimates)
                    + ". Country-clustered standard errors use only the available country clusters."
                )
        elif label == "Table 6":
            row = frame.iloc[0]
            lines.append(
                f"The pooled intervention effect is g1={_number(row.get('g1'))} "
                f"(p={_number(row.get('g1_p'), 3)}) in OFF periods and g3="
                f"{_number(row.get('g3'))} (p={_number(row.get('g3_p'), 3)}) for the "
                f"incremental crisis relationship. The estimated ON effect g1+g3 is "
                f"{_number(row.get('g1_plus_g3'))} (p={_number(row.get('g1_plus_g3_p'), 3)})."
            )
        elif label == "Table 7":
            row = frame.iloc[0]
            lines.append(
                f"The estimated incremental intervention coefficients are "
                f"{_number(row.get('g3_gfc'))} for GFC and {_number(row.get('g3_covid'))} "
                f"for COVID. The formal equality test has p="
                f"{_number(row.get('gfc_equals_covid_p'), 3)}."
            )
        elif label == "Table 8":
            rows = [
                f"{row.check}: g3={_number(row.g3)}, p={_number(row.g3_p, 3)}, "
                f"g1+g3={_number(row.g1_plus_g3)}"
                for row in frame.itertuples(index=False)
            ]
            lines.append("Robustness estimates: " + "; ".join(rows) + ".")
        elif label == "DataDescription":
            lines.append(
                f"The data-description table covers {frame['variable'].nunique()} variables, "
                f"their observed frequencies, sample ranges and non-missing record counts."
            )
        else:
            lines.append(
                f"The table contains {len(frame)} rows from the estimated outputs; "
                "direction and significance are shown in its country-level rows."
            )
        lines.append("")
    if (OUTPUT_DIR / "stage1_replication.csv").exists():
        rep = pd.read_csv(OUTPUT_DIR / "stage1_replication.csv")
        mean_beta = rep["beta_s"].mean() if not rep.empty else np.nan
        lines.extend(
            [
                "## Replication direction comparison",
                f"The estimated mean signed replication exposure in this sample is "
                f"{_number(mean_beta)}. The original paper's direction is not imported into "
                "the calculations; interpret this sample estimate alongside the paper's "
                "reported qualitative result.",
                "",
            ]
        )
    (OUTPUT_DIR / "results_summary.md").write_text("\n".join(lines), encoding="utf-8")


def export_excel():
    readme_rows = [
        ("Field", "Value"),
        ("Data sources", "BIS, World Bank, Yahoo Finance; IMF monthly retry received HTTP 403."),
        ("BIS URL", BIS_MANUAL_URL),
        ("World Bank URL", "https://api.worldbank.org/v2/"),
        ("Yahoo URL", "https://finance.yahoo.com/"),
        ("Download date", date.today().isoformat()),
        ("Market/firm price frequency", "Monthly adjusted close"),
        ("Intervention and country controls frequency", "Annual World Bank observations; not interpolated"),
        ("Sample period", "2001-04 through 2025-12 or latest source observation"),
        ("NEER return", "ln(NEER_t / NEER_t-1); positive means local currency appreciation"),
        ("Firm exposure", "R_it = b0 + b_m R_m,t + b_s R_s,t + e_it"),
        ("Intervention proxy", "Change in (FX reserves excluding gold, converted to LCU / M2)"),
        ("COVID windows", "Sikarwar (2023), Table A2; Indonesia, Korea and Thailand flagged VERIFY"),
        ("GFC window", "2007-08 through 2009-06; alternative 2008-08 through 2009-06"),
        ("Limitations", "See README.md for survivorship, sample, frequency, firm-control and clustering limitations."),
    ]
    for row in pd.read_csv(CLEAN_DIR / "intervention_source.csv").itertuples(index=False):
        readme_rows.append(
            (f"Intervention source: {row.country}", row.source)
        )
    sheets = {
        "README": pd.DataFrame(readme_rows[1:], columns=readme_rows[0]),
        "raw_neer": pd.read_csv(CLEAN_DIR / "neer_monthly.csv"),
        "raw_market_index": pd.read_csv(CLEAN_DIR / "market_index_monthly.csv"),
        "raw_stock_prices": pd.read_csv(CLEAN_DIR / "firm_prices_monthly.csv"),
        "raw_intervention": pd.read_csv(CLEAN_DIR / "intervention_annual.csv"),
        "raw_country_controls": pd.read_csv(CLEAN_DIR / "country_controls_annual.csv"),
        "firm_info": pd.read_csv(CLEAN_DIR / "firm_info.csv"),
        "firm_coverage": pd.read_csv(CLEAN_DIR / "firm_coverage.csv"),
        "crisis_calendar": pd.read_csv(CLEAN_DIR / "crisis_calendar.csv"),
        "stage1_replication": pd.read_csv(OUTPUT_DIR / "stage1_replication.csv"),
        "stage1_on_off": pd.read_csv(OUTPUT_DIR / "stage1_on_off.csv"),
        "stage2_replication": pd.read_csv(OUTPUT_DIR / "stage2_replication.csv"),
        "stage2_extension": pd.read_csv(OUTPUT_DIR / "stage2_extension.csv"),
        "robustness": pd.read_csv(OUTPUT_DIR / "robustness.csv"),
        "dropped_firms_log": pd.read_csv(OUTPUT_DIR / "dropped_firms_log.csv")
        if (OUTPUT_DIR / "dropped_firms_log.csv").exists() else pd.DataFrame(),
    }
    for filename in (
        "Table1A_country_stats.csv", "Table2_exposure_replication.csv",
        "Table2b_exposure_on_off.csv", "Table2b_exposure_gfc_covid.csv",
        "Table3_eq4.csv", "Table4_eq5.csv",
        "Table5_eq6.csv", "Table6_crisis_interaction.csv",
        "Table7_gfc_vs_covid.csv", "Table8_robustness.csv", "DataDescription.csv",
    ):
        path = OUTPUT_DIR / filename
        if path.exists():
            sheet = filename.removesuffix(".csv")[:31]
            sheets[sheet] = pd.read_csv(path)
    with pd.ExcelWriter(OUTPUT_DIR / "Assignment2_Data_and_Results.xlsx", engine="openpyxl") as writer:
        for name, frame in sheets.items():
            frame.to_excel(writer, sheet_name=name[:31], index=False)


def main():
    setup_logging()
    description = create_tables()
    create_figures()
    write_results_summary()
    export_excel()
    logging.info(
        "Stage 4 complete: %d data-description rows; workbook, CSV tables, figures and summary created",
        len(description),
    )


if __name__ == "__main__":
    main()

"""Estimate firm exchange-rate exposure for the replication and crisis extension.

Implements Sikarwar (2020) Eq. 1 in the replication window and the
Sikarwar (2023) period-specific exposure model over the full sample.
"""

import logging
import warnings

import numpy as np
import pandas as pd
import statsmodels.api as sm
from arch import arch_model
from scipy.stats import norm
from statsmodels.stats.diagnostic import het_arch
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.tsa.stattools import adfuller

from config import (
    CLEAN_DIR,
    COUNTRIES,
    COVID_WINDOWS,
    END_DATE,
    GFC_WINDOWS,
    MARKET_TICKERS,
    OUTPUT_DIR,
    REPLICATION_END,
    REPLICATION_START,
    WORLD_MARKET_TICKERS,
)

LOG_PATH = OUTPUT_DIR / "stage1.log"


def setup_logging():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        handlers=[logging.FileHandler(LOG_PATH, encoding="utf-8"), logging.StreamHandler()],
        force=True,
    )


def _month_end(series):
    return pd.to_datetime(series).dt.to_period("M").dt.to_timestamp("M")


def build_return_panel(world_market=False):
    """Build observed monthly log returns; never fill missing price observations."""
    stocks = pd.read_csv(CLEAN_DIR / "firm_prices_monthly.csv", parse_dates=["date"])
    stocks = stocks[["ticker", "date", "adjusted_close", "name", "country", "sector"]].drop_duplicates(
        ["ticker", "date"], keep="last"
    )
    stocks["date"] = _month_end(stocks["date"])
    stocks = stocks.loc[stocks["adjusted_close"] > 0]
    stocks = stocks.sort_values(["ticker", "date"])
    stocks["ret_stock"] = stocks.groupby("ticker")["adjusted_close"].transform(
        lambda x: np.log(x / x.shift(1))
    )

    market = pd.read_csv(CLEAN_DIR / "market_index_monthly.csv", parse_dates=["date"])
    market["date"] = _month_end(market["date"])
    market = market.loc[market["adjusted_close"] > 0]
    market = market.drop_duplicates(["ticker", "date"]).sort_values(["ticker", "date"])
    market["ret_market"] = market.groupby("ticker")["adjusted_close"].transform(
        lambda x: np.log(x / x.shift(1))
    )

    neer = pd.read_csv(CLEAN_DIR / "neer_monthly.csv", parse_dates=["date"])
    neer["date"] = _month_end(neer["date"])
    neer = neer.loc[neer["neer"] > 0]
    neer = neer.drop_duplicates(["iso2", "date"]).sort_values(["iso2", "date"])
    neer["ret_neer"] = neer.groupby("iso2")["neer"].transform(lambda x: np.log(x / x.shift(1)))
    iso_to_country = {v["bis"]: k for k, v in COUNTRIES.items()}
    neer["country"] = neer["iso2"].map(iso_to_country)
    neer = neer[["country", "date", "neer", "ret_neer"]]

    market_map = {}
    for country in COUNTRIES:
        candidates = WORLD_MARKET_TICKERS if world_market else MARKET_TICKERS.get(country, [])
        available = market.loc[market["ticker"].isin(candidates)]
        if available.empty:
            market_map[country] = None
            continue
        counts = available.groupby("ticker")["ret_market"].count().sort_values(ascending=False)
        selected = counts.index[0]
        market_map[country] = selected
    records = []
    for country, ticker in market_map.items():
        if ticker is None:
            logging.warning("%s has no downloaded %s index; cannot estimate exposure", country,
                            "world-market" if world_market else "local-market")
            continue
        country_market = market.loc[market["ticker"] == ticker, ["date", "ret_market"]]
        country_stocks = stocks.loc[stocks["country"] == country]
        joined = country_stocks.merge(country_market, on="date", how="inner")
        joined = joined.merge(neer.loc[neer["country"] == country, ["date", "ret_neer", "neer"]],
                              on="date", how="inner")
        joined["market_ticker"] = ticker
        records.append(joined)
    if not records:
        return pd.DataFrame()
    frame = pd.concat(records, ignore_index=True)
    frame = frame.replace([np.inf, -np.inf], np.nan).dropna(
        subset=["ret_stock", "ret_market", "ret_neer"]
    )
    frame = frame.sort_values(["country", "ticker", "date"])
    frame.to_csv(CLEAN_DIR / ("return_panel_world.csv" if world_market else "return_panel.csv"),
                 index=False)
    return frame


def _adf_row(country, firm, variable, values):
    values = pd.Series(values).dropna()
    if len(values) < 20 or values.nunique() < 2:
        return {
            "country": country, "firm": firm, "variable": variable,
            "n_obs": len(values), "adf_stat": np.nan, "p_value": np.nan,
            "used_lags": np.nan, "critical_1pct": np.nan,
            "critical_5pct": np.nan, "critical_10pct": np.nan,
            "error": "insufficient observations or constant series",
        }
    try:
        stat, p_value, used_lags, _, critical, _ = adfuller(values, autolag="AIC")
        return {
            "country": country, "firm": firm, "variable": variable,
            "n_obs": len(values), "adf_stat": stat, "p_value": p_value,
            "used_lags": used_lags, "critical_1pct": critical["1%"],
            "critical_5pct": critical["5%"], "critical_10pct": critical["10%"],
            "error": "",
        }
    except Exception as exc:
        return {
            "country": country, "firm": firm, "variable": variable,
            "n_obs": len(values), "adf_stat": np.nan, "p_value": np.nan,
            "used_lags": np.nan, "critical_1pct": np.nan,
            "critical_5pct": np.nan, "critical_10pct": np.nan,
            "error": str(exc),
        }


def _fit_regression(y, X):
    """Apply the residual ARCH-LM decision rule, with explicit HAC fallback."""
    X = sm.add_constant(X, has_constant="add")
    ols = sm.OLS(y, X).fit()
    try:
        arch_lm, arch_p, _, _ = het_arch(ols.resid, nlags=5)
    except Exception as exc:
        arch_lm, arch_p = np.nan, 1.0
        logging.warning("ARCH-LM test unavailable; using HAC: %s", exc)
    if arch_p < 0.05:
        try:
            model = arch_model(
                y,
                x=X.drop(columns="const"),
                mean="LS",
                vol="GARCH",
                p=1,
                q=1,
                dist="normal",
            )
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                fitted = model.fit(disp="off", show_warning=False)
            if fitted.convergence_flag != 0:
                raise RuntimeError(f"GARCH did not converge (flag={fitted.convergence_flag})")
            return fitted, "GARCH(1,1)", arch_lm, arch_p
        except Exception as exc:
            logging.warning("GARCH failed; falling back to OLS-HAC: %s", exc)
    maxlags = int(4 * (len(y) / 100) ** (2 / 9))
    fitted = sm.OLS(y, X).fit(
        cov_type="HAC",
        cov_kwds={"maxlags": max(1, maxlags)},
    )
    return fitted, "OLS-HAC", arch_lm, arch_p


def _param(fitted, name):
    return {
        "beta": float(fitted.params[name]),
        "se": float(fitted.std_err[name] if hasattr(fitted, "std_err") else fitted.bse[name]),
        "t": float(fitted.tvalues[name]),
        "p": float(fitted.pvalues[name]),
    }


def _wald_difference(fitted, first, second):
    names = list(fitted.params.index)
    if first not in names or second not in names:
        return np.nan
    contrast = np.zeros(len(names))
    contrast[names.index(first)] = 1
    contrast[names.index(second)] = -1
    try:
        covariance = fitted.param_cov if hasattr(fitted, "param_cov") else fitted.cov_params()
        variance = float(contrast @ np.asarray(covariance) @ contrast)
    except Exception as exc:
        logging.warning("Wald covariance unavailable for %s vs %s: %s", first, second, exc)
        return np.nan
    if variance <= 0 or not np.isfinite(variance):
        return np.nan
    z_score = float(contrast @ np.asarray(fitted.params) / np.sqrt(variance))
    return float(2 * norm.sf(abs(z_score)))


def _country_available_window(frame, start, end):
    start_period, end_period = pd.Period(start, "M"), pd.Period(end, "M")
    return frame.loc[frame["date"].dt.to_period("M").between(start_period, end_period)].copy()


def _eligible_countries(coverage, window):
    counts = (
        coverage.loc[coverage[f"{window}_pass"]]
        .groupby("country")["firm"].nunique()
    )
    return set(counts[counts >= 3].index)


def _fit_firm_model(sample, X, beta_names):
    # Eq.(1): R_it = b0 + b_m*R_m,t + b_s*R_s,t + e_it.
    y = sample["ret_stock"].astype(float)
    fitted, model_used, arch_lm, arch_p = _fit_regression(y, sample[X].astype(float))
    values = {name: _param(fitted, name) for name in beta_names}
    values.update({"fitted": fitted, "model_used": model_used, "arch_lm": arch_lm, "arch_p": arch_p})
    return values


def _month_masks(country, frame, use_alternative_gfc=False):
    gfc_window = GFC_WINDOWS["alternative" if use_alternative_gfc else "primary"]
    months = frame["date"].dt.to_period("M").astype(str)
    gfc = months.between(gfc_window[0], gfc_window[1])
    covid_start, covid_end = COVID_WINDOWS[country]
    covid = months.between(covid_start, covid_end)
    return gfc, covid


def run_stage1(world_market=False, use_alternative_gfc=False, write_outputs=True):
    """Estimate replication and crisis exposures; world_market toggles Stage 1 robustness."""
    setup_logging()
    suffix = "_world" if world_market else ""
    panel = build_return_panel(world_market=world_market)
    coverage = pd.read_csv(CLEAN_DIR / "firm_coverage.csv")
    coverage["ticker"] = coverage["firm"]
    eligible_rep = _eligible_countries(coverage, "replication")
    eligible_ext = _eligible_countries(coverage, "extension")
    if use_alternative_gfc:
        gfc_start, gfc_end = GFC_WINDOWS["alternative"]
    else:
        gfc_start, gfc_end = GFC_WINDOWS["primary"]

    replication_rows, extension_rows, adf_rows, vif_rows = [], [], [], []
    for country, data in panel.groupby("country"):
        if data.empty:
            continue
        country_mask = data["date"].between(pd.Timestamp("2001-04-01"), pd.Timestamp(END_DATE))
        sample_full = data.loc[country_mask]
        if sample_full.empty:
            continue
        first = sample_full.drop_duplicates("date").sort_values("date")
        corr = first[["ret_market", "ret_neer"]].corr().iloc[0, 1]
        rs_vif = float(variance_inflation_factor(sm.add_constant(first[["ret_market", "ret_neer"]]).values, 2))
        vif_rows.append(
            {"country": country, "market_ticker": first["market_ticker"].iloc[0],
             "correlation_rm_rs": corr, "vif_market": rs_vif, "vif_neer": rs_vif}
        )
        rep_dates = _country_available_window(sample_full, "2001-04", "2017-03")
        if country in eligible_rep:
            n_expected = 191
            n_market_rs = rep_dates[["date"]].drop_duplicates().shape[0]
            if n_market_rs < int(np.ceil(0.8 * n_expected)):
                logging.warning("Excluding %s from replication: only %d aligned months (%d required)",
                                country, n_market_rs, int(np.ceil(0.8 * n_expected)))
            else:
                country_dates = rep_dates.drop_duplicates("date").sort_values("date")
                adf_rows.append(_adf_row(country, "", "R_m", country_dates["ret_market"]))
                adf_rows.append(_adf_row(country, "", "R_s", country_dates["ret_neer"]))
                for ticker, firm_data in rep_dates.groupby("ticker"):
                    firm_cov = coverage.loc[coverage["firm"] == ticker]
                    if firm_cov.empty or not bool(firm_cov.iloc[0]["replication_pass"]):
                        continue
                    y_sample = firm_data.dropna(subset=["ret_stock", "ret_market", "ret_neer"])
                    if len(y_sample) < 30:
                        continue
                    adf_rows.append(_adf_row(country, ticker, "R_i", y_sample["ret_stock"]))
                    try:
                        fitted = _fit_firm_model(y_sample, ["ret_market", "ret_neer"], ["ret_neer"])
                        beta = fitted["ret_neer"]
                        beta_m = _param(fitted["fitted"], "ret_market")
                        replication_rows.append(
                            {
                                "firm": ticker, "country": country,
                                "sector": firm_data["sector"].iloc[0],
                                "beta_s": beta["beta"], "se": beta["se"],
                                "t": beta["t"], "p": beta["p"],
                                "sig10": bool(beta["p"] < 0.10),
                                "sign": "positive" if beta["beta"] > 0 else "negative" if beta["beta"] < 0 else "zero",
                                "beta_m": beta_m["beta"], "model_used": fitted["model_used"],
                                "n_obs": len(y_sample),
                                "adj_r2": float(getattr(fitted["fitted"], "rsquared_adj", np.nan)),
                                "arch_lm": fitted["arch_lm"], "arch_p": fitted["arch_p"],
                            }
                        )
                    except Exception as exc:
                        logging.warning("Replication failed for %s: %s", ticker, exc)

        if country not in eligible_ext:
            logging.warning("Country %s excluded from extension: fewer than 3 screened firms", country)
            continue
        extension_dates = _country_available_window(sample_full, "2001-04", "2025-12")
        if extension_dates["date"].nunique() < int(np.ceil(0.8 * 296)):
            logging.warning(
                "Excluding %s from extension: only %d aligned months (%d required)",
                country,
                extension_dates["date"].nunique(),
                int(np.ceil(0.8 * 296)),
            )
            continue
        for ticker, firm_data in extension_dates.groupby("ticker"):
            firm_cov = coverage.loc[coverage["firm"] == ticker]
            if firm_cov.empty or not bool(firm_cov.iloc[0]["extension_pass"]):
                continue
            gfc, covid = _month_masks(country, firm_data, use_alternative_gfc)
            off = ~(gfc | covid)
            # Extension A: R_it = b0 + b_m*R_m + b_OFF*(OFF*R_s) + b_ON*(CRISIS*R_s) + e.
            model_a = firm_data.copy()
            model_a["off_rs"] = off.astype(float) * model_a["ret_neer"]
            model_a["on_rs"] = (gfc | covid).astype(float) * model_a["ret_neer"]
            # Extension B: replace ON with separate GFC and COVID exchange-rate interactions.
            model_b = firm_data.copy()
            model_b["off_rs"] = off.astype(float) * model_b["ret_neer"]
            model_b["gfc_rs"] = gfc.astype(float) * model_b["ret_neer"]
            model_b["covid_rs"] = covid.astype(float) * model_b["ret_neer"]
            try:
                fit_a = _fit_firm_model(model_a, ["ret_market", "off_rs", "on_rs"],
                                         ["off_rs", "on_rs"])
                p_a = _wald_difference(fit_a["fitted"], "on_rs", "off_rs")
                fit_b = _fit_firm_model(model_b, ["ret_market", "off_rs", "gfc_rs", "covid_rs"],
                                         ["off_rs", "gfc_rs", "covid_rs"])
                p_b = _wald_difference(fit_b["fitted"], "gfc_rs", "covid_rs")
            except Exception as exc:
                logging.warning("Extension failed for %s: %s", ticker, exc)
                continue
            firm_cov_row = firm_cov.iloc[0]
            for model_name, model_fit, coef_periods, wald_p in (
                ("crisis_on_off", fit_a, {"OFF": "off_rs", "ON": "on_rs"}, p_a),
                ("gfc_covid", fit_b, {"OFF": "off_rs", "GFC": "gfc_rs", "COVID": "covid_rs"}, p_b),
            ):
                for period, coef_name in coef_periods.items():
                    coverage_flag = {
                        "OFF": "extension_pass",
                        "ON": "extension_pass",
                        "GFC": "GFC_pass",
                        "COVID": "COVID_pass",
                    }[period]
                    if not bool(firm_cov_row[coverage_flag]):
                        continue
                    values = model_fit[coef_name]
                    extension_rows.append(
                        {
                            "firm": ticker, "country": country,
                            "sector": firm_data["sector"].iloc[0],
                            "model": model_name, "period": period,
                            "beta": values["beta"], "se": values["se"],
                            "p": values["p"], "sig10": bool(values["p"] < 0.10),
                            "abs_beta": abs(values["beta"]),
                            "wald_p_on_off": p_a, "wald_p_gfc_covid": p_b,
                            "model_used": model_fit["model_used"],
                            "n_obs": len(firm_data),
                        }
                    )

    replication = pd.DataFrame(replication_rows)
    extension = pd.DataFrame(extension_rows)
    adf = pd.DataFrame(adf_rows)
    vif = pd.DataFrame(vif_rows)
    if write_outputs:
        replication.to_csv(OUTPUT_DIR / f"stage1_replication{suffix}.csv", index=False)
        extension.to_csv(OUTPUT_DIR / f"stage1_on_off{suffix}.csv", index=False)
        adf.to_csv(OUTPUT_DIR / f"stage1_adf{suffix}.csv", index=False)
        vif.to_csv(OUTPUT_DIR / f"stage1_vif{suffix}.csv", index=False)
        _save_exposure_summaries(replication, extension, panel, suffix)
    logging.info(
        "Stage 1 complete%s: replication firms=%d, extension firm-period rows=%d, "
        "countries in estimates=%d",
        " (world-market robustness)" if world_market else "",
        len(replication),
        len(extension),
        len(set(replication.get("country", [])) | set(extension.get("country", []))),
    )
    return replication, extension, panel


def _save_exposure_summaries(replication, extension, panel, suffix=""):
    def summary(frame, key, beta_col, sig_col, rs_sd, total_rs_sd=np.nan):
        rows = []
        groups = list(frame.groupby(key)) if not frame.empty else []
        for country, group in groups:
            significant = group.loc[group[sig_col]]
            beta = group[beta_col]
            rows.append(
                {
                    "country": country, "n_firms": group["firm"].nunique(),
                    "n_sig10": significant["firm"].nunique(),
                    "pct_sig10": 100 * significant["firm"].nunique() / group["firm"].nunique(),
                    "n_sig_positive": int((significant[beta_col] > 0).sum()),
                    "n_sig_negative": int((significant[beta_col] < 0).sum()),
                    "mean_beta": beta.mean(), "mean_abs_beta": beta.abs().mean(),
                    "mean_positive_beta": beta[beta > 0].mean(),
                    "mean_negative_beta": beta[beta < 0].mean(),
                    "economic_significance": beta.mean() * rs_sd.get(country, np.nan),
                    "pct_wald_reject": (
                        100 * group["wald_p_on_off"].lt(0.10).mean()
                        if "wald_p_on_off" in group else np.nan
                    ),
                }
            )
        if rows:
            result = pd.DataFrame(rows)
            result.loc[len(result)] = {
                "country": "Total",
                "n_firms": frame["firm"].nunique(),
                "n_sig10": frame.loc[frame[sig_col], "firm"].nunique(),
                "pct_sig10": 100 * frame.loc[frame[sig_col], "firm"].nunique() / frame["firm"].nunique(),
                "n_sig_positive": int((frame.loc[frame[sig_col], beta_col] > 0).sum()),
                "n_sig_negative": int((frame.loc[frame[sig_col], beta_col] < 0).sum()),
                "mean_beta": frame[beta_col].mean(),
                "mean_abs_beta": frame[beta_col].abs().mean(),
                "mean_positive_beta": frame.loc[frame[beta_col] > 0, beta_col].mean(),
                "mean_negative_beta": frame.loc[frame[beta_col] < 0, beta_col].mean(),
                "economic_significance": frame[beta_col].mean() * total_rs_sd,
                "pct_wald_reject": (
                    100 * frame["wald_p_on_off"].lt(0.10).mean()
                    if "wald_p_on_off" in frame else np.nan
                ),
            }
            return result
        return pd.DataFrame()

    panel["month"] = panel["date"].dt.to_period("M").astype(str)
    rep_dates = panel.loc[panel["month"].between("2001-04", "2017-03")]
    rep_unique = rep_dates.drop_duplicates(["country", "date"])
    rep_rs_sd = rep_unique.groupby("country")["ret_neer"].std().to_dict()
    rep_summary = summary(
        replication, "country", "beta_s", "sig10", rep_rs_sd,
        rep_unique["ret_neer"].std() if not rep_unique.empty else np.nan,
    )
    if not rep_summary.empty:
        rep_summary.to_csv(OUTPUT_DIR / f"Table2_exposure_replication{suffix}.csv", index=False)
    if extension.empty:
        return
    calendar = pd.read_csv(CLEAN_DIR / "crisis_calendar.csv")
    panel_periods = panel.drop_duplicates(["country", "date"]).merge(
        calendar, left_on=["country", "month"], right_on=["country", "month"], how="left"
    )
    for model in ("crisis_on_off", "gfc_covid"):
        period_results = []
        for period in extension.loc[extension["model"] == model, "period"].unique():
            frame = extension.loc[
                (extension["model"] == model) & (extension["period"] == period)
            ].copy()
            if period == "OFF":
                period_panel = panel_periods.loc[panel_periods["period"] == "OFF"]
            elif period == "ON":
                period_panel = panel_periods.loc[panel_periods["period"] == "ON"]
            elif period == "GFC":
                period_panel = panel_periods.loc[panel_periods["gfc"] == 1]
            else:
                period_panel = panel_periods.loc[panel_periods["covid"] == 1]
            rs_sd = period_panel.groupby("country")["ret_neer"].std().to_dict()
            result = summary(
                frame, "country", "beta", "sig10", rs_sd,
                period_panel["ret_neer"].std() if not period_panel.empty else np.nan,
            )
            if not result.empty:
                result.insert(0, "model", model)
                result.insert(1, "period", period)
                period_results.append(result)
        if period_results:
            output_name = (
                "Table2b_exposure_on_off" if model == "crisis_on_off"
                else "Table2b_exposure_gfc_covid"
            )
            pd.concat(period_results, ignore_index=True).to_csv(
                OUTPUT_DIR / f"{output_name}{suffix}.csv", index=False
            )


if __name__ == "__main__":
    run_stage1()

"""Run the cached data, Stage 1 Eq. (1), Stage 2 Eq. (4-6), and reporting pipeline."""

import subprocess
import sys
from pathlib import Path

import pandas as pd

from config import BASE_DIR, CLEAN_DIR, OUTPUT_DIR


def run_step(script):
    path = BASE_DIR / script
    print(f"\n=== Running {script} ===", flush=True)
    completed = subprocess.run(
        [sys.executable, str(path)],
        cwd=BASE_DIR,
        check=False,
    )
    if completed.returncode != 0:
        raise RuntimeError(
            f"{script} failed with exit code {completed.returncode}; "
            f"review its log and correct the error before continuing."
        )


def print_final_summary():
    print("\n=== Firm coverage passing the screen (per country) ===")
    coverage = pd.read_csv(CLEAN_DIR / "firm_coverage.csv")
    for window in ("replication", "extension", "GFC", "COVID"):
        counts = (
            coverage.loc[coverage[f"{window}_pass"]]
            .groupby("country")["firm"]
            .nunique()
            .sort_index()
        )
        print(f"{window}:")
        print(counts.to_string())

    print("\n=== Firms actually included in Stage 1 estimates ===")
    replication = pd.read_csv(OUTPUT_DIR / "stage1_replication.csv")
    if not replication.empty:
        print("Replication:")
        print(replication.groupby("country")["firm"].nunique().sort_index().to_string())
    extension = pd.read_csv(OUTPUT_DIR / "stage1_on_off.csv")
    for model, periods, label in (
        ("crisis_on_off", ("OFF", "ON"), "OFF / ON"),
        ("gfc_covid", ("GFC", "COVID"), "GFC / COVID"),
    ):
        print(f"{label}:")
        selected = extension.loc[
            (extension["model"] == model) & extension["period"].isin(periods)
        ]
        if not selected.empty:
            print(
                selected.groupby(["period", "country"])["firm"]
                .nunique()
                .unstack("period", fill_value=0)
                .sort_index()
                .to_string()
            )

    print("\n=== Significant exposure shares ===")
    rep = replication
    if not rep.empty:
        print(f"Replication: {100 * rep['sig10'].mean():.1f}% ({len(rep)} firm estimates)")
    extension = extension.loc[extension["model"] == "crisis_on_off"]
    for period in ("OFF", "ON"):
        frame = extension.loc[extension["period"] == period]
        if not frame.empty:
            print(f"{period}: {100 * frame['sig10'].mean():.1f}% ({len(frame)} firm estimates)")
    split = pd.read_csv(OUTPUT_DIR / "stage1_on_off.csv")
    split = split.loc[split["model"] == "gfc_covid"]
    for period in ("GFC", "COVID"):
        frame = split.loc[split["period"] == period]
        if not frame.empty:
            print(f"{period}: {100 * frame['sig10'].mean():.1f}% ({len(frame)} firm estimates)")

    print("\n=== Main pooled effects ===")
    summary_path = OUTPUT_DIR / "stage2_interaction_summary.csv"
    if summary_path.exists():
        summary = pd.read_csv(summary_path)
        if not summary.empty:
            row = summary.iloc[0]
            for label, value, p_value in (
                ("g1 (OFF)", row.get("g1"), row.get("g1_p")),
                ("g3 (incremental crisis effect)", row.get("g3"), row.get("g3_p")),
                ("g1+g3 (ON)", row.get("g1_plus_g3"), row.get("g1_plus_g3_p")),
            ):
                print(f"{label}: {value} (p={p_value})")
            split_path = OUTPUT_DIR / "stage2_gfc_covid_test.csv"
            if split_path.exists():
                split_test = pd.read_csv(split_path)
                if not split_test.empty:
                    print(f"GFC vs COVID equality-test p-value: {split_test.iloc[0]['gfc_equals_covid_p']}")

    print("\n=== Output files ===")
    for path in sorted(OUTPUT_DIR.iterdir()):
        if path.is_file():
            print(path.name)


def main():
    for script in (
        "01_get_data.py",
        "02_stage1_exposure.py",
        "03_stage2_regressions.py",
        "04_tables_figures.py",
    ):
        run_step(script)
    print_final_summary()


if __name__ == "__main__":
    main()

# Results summary

All statements below are calculated from the estimates saved in this output folder. No coefficient or significance result from either cited paper is hard-coded.

## Table 1A
ADF results: R_i: 48/48 tests reject at 5%; R_m: 6/6 tests reject at 5%; R_s: 6/6 tests reject at 5%.

## Table 2
Across 48 firms, 7 (14.6%) have significant exposure at 10%. The mean signed beta is -0.0538, mean |beta| is 0.3941, and the significant signs are 2 positive and 5 negative.

## Table 2b
OFF: mean |beta|=0.3434, significant=22.6%, Wald rejections=20.8%; ON: mean |beta|=0.5751, significant=20.8%, Wald rejections=20.8%.

## Table 3
Intervention estimates: all_abs_beta: INT=-83.6187** (HC1 p=0.027, N=48); positive_signed_beta: INT=-169.2928* (HC1 p=0.066, N=22); negative_signed_beta: INT=32.3461 (HC1 p=0.213, N=26); significant_abs_beta: not estimable (too few observations). Country-clustered standard errors use only the available country clusters.

## Table 4
Intervention estimates: all_abs_beta: INT=-81.6884* (HC1 p=0.082, N=48); positive_signed_beta: INT=-163.5333 (HC1 p=0.107, N=22); negative_signed_beta: INT=35.5521 (HC1 p=0.214, N=26); significant_abs_beta: not estimable (too few observations). Country-clustered standard errors use only the available country clusters.

## Table 5
Intervention estimates: all_abs_beta: INT=-81.6884* (HC1 p=0.082, N=48); positive_signed_beta: INT=-163.5333 (HC1 p=0.107, N=22); negative_signed_beta: INT=35.5521 (HC1 p=0.214, N=26); significant_abs_beta: not estimable (too few observations). Country-clustered standard errors use only the available country clusters.

## Table 6
The pooled intervention effect is g1=30.5337 (p=0.320) in OFF periods and g3=-31.6227 (p=0.300) for the incremental crisis relationship. The estimated ON effect g1+g3 is -1.0891 (p=0.720).

## Table 7
The estimated incremental intervention coefficients are -64.1211 for GFC and -44.2077 for COVID. The formal equality test has p=0.023.

## Table 8
Robustness estimates: baseline: g3=-31.6227, p=0.300, g1+g3=-1.0891; exclude_Korea: g3=-48.4630, p=0.327, g1+g3=-1.8661; sqrt_abs_beta: g3=-22.4326, p=0.289, g1+g3=-1.1006; world_market: g3=9.7036, p=0.643, g1+g3=-6.0739; reserves_GDP: g3=-85.9159, p=0.117, g1+g3=-5.2798; alternative_GFC: g3=-7.8903, p=0.795, g1+g3=16.1848.

## DataDescription
The data-description table covers 18 variables, their observed frequencies, sample ranges and non-missing record counts.

## Replication direction comparison
The estimated mean signed replication exposure in this sample is -0.0538. The original paper's direction is not imported into the calculations; interpret this sample estimate alongside the paper's reported qualitative result.

"""Shared settings and country metadata for the FX exposure assignment."""

from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
RAW_DIR = BASE_DIR / "data" / "raw"
CLEAN_DIR = BASE_DIR / "data" / "clean"
OUTPUT_DIR = BASE_DIR / "output"

START_DATE = "2001-04-01"
END_DATE = "2025-12-31"
END_DATE_EXCLUSIVE = "2026-01-01"
REPLICATION_START = "2001-04"
REPLICATION_END = "2017-03"
FREQ = "M"
FREQUENCY = FREQ
FORCE_DOWNLOAD = False

COUNTRIES = {
    "Brazil": {"iso2": "BR", "iso3": "BRA", "bis": "BR"},
    "Colombia": {"iso2": "CO", "iso3": "COL", "bis": "CO"},
    "India": {"iso2": "IN", "iso3": "IND", "bis": "IN"},
    "Indonesia": {"iso2": "ID", "iso3": "IDN", "bis": "ID"},
    "Korea": {"iso2": "KR", "iso3": "KOR", "bis": "KR"},
    "Peru": {"iso2": "PE", "iso3": "PER", "bis": "PE"},
    "Philippines": {"iso2": "PH", "iso3": "PHL", "bis": "PH"},
    "South Africa": {"iso2": "ZA", "iso3": "ZAF", "bis": "ZA"},
    "Thailand": {"iso2": "TH", "iso3": "THA", "bis": "TH"},
    "Turkey": {"iso2": "TR", "iso3": "TUR", "bis": "TR"},
}

MARKET_TICKERS = {
    "Brazil": ["^BVSP"],
    "Colombia": ["^COLCAP", "ICOLCAP.CL"],
    "India": ["^BSESN"],
    "Indonesia": ["^JKSE"],
    "Korea": ["^KS11"],
    "Peru": ["^SPBLPGPT"],
    "Philippines": ["PSEI.PS"],
    "South Africa": ["^J203.JO", "STX40.JO"],
    "Thailand": ["^SET.BK"],
    "Turkey": ["XU100.IS"],
}
WORLD_MARKET_TICKERS = ["URTH", "^990100-USD-STRD"]

# GFC_ON follows the credit-crunch-to-NBER-recession window. Set USE_ALTERNATIVE_GFC
# to True to use the shorter Aug 2008-Jun 2009 window as a robustness check.
USE_ALTERNATIVE_GFC = False
GFC_WINDOWS = {
    "primary": ("2007-08", "2009-06"),
    "alternative": ("2008-08", "2009-06"),
}

# COVID windows follow Sikarwar (2023), Table A2. Indonesia, Korea and Thailand
# are not listed there and are marked VERIFY pending confirmation.
COVID_WINDOWS = {
    "Brazil": ("2020-02", "2021-01"),
    "Colombia": ("2020-03", "2021-02"),
    "India": ("2020-01", "2021-01"),
    "Indonesia": ("2020-03", "2021-01"),  # VERIFY
    "Korea": ("2020-01", "2021-02"),  # VERIFY
    "Peru": ("2020-03", "2021-02"),
    "Philippines": ("2020-01", "2021-03"),
    "South Africa": ("2020-03", "2021-02"),
    "Thailand": ("2020-01", "2021-02"),  # VERIFY
    "Turkey": ("2020-03", "2021-01"),
}

WORLD_BANK_INDICATORS = {
    "reserves_usd": "FI.RES.XGLD.CD",
    "broad_money_lcu": "FM.LBL.BMNY.CN",
    "exchange_rate_lcu_per_usd": "PA.NUS.FCRF",
    "openness": "NE.TRD.GNFS.ZS",
    "broad_money_gdp": "FM.LBL.BMNY.GD.ZS",
    "gdp_per_capita_usd": "NY.GDP.PCAP.CD",
    "gdp_lcu": "NY.GDP.MKTP.CN",
}

IMF_DATASET = "IFS"
IMF_API_BASE = "https://api.imf.org/external/sdmx/2.1/data"
BIS_DATAFLOW = "WS_EER"
BIS_API_BASES = [
    "https://data.bis.org/api/v1/data",
    "https://stats.bis.org/api/v1/data",
]
BIS_MANUAL_URL = "https://data.bis.org/topics/EER"
